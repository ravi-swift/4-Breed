//
//  SeetingViewController.swift
//  4Breeders
//
//  Created by Rp on 07/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class SeetingViewController: UIViewController,selectCountry {

    @IBOutlet weak var viewCountrySelect: UIView!
    
    @IBOutlet var imgViewRussia : UIImageView!
    @IBOutlet var imgViewUsa : UIImageView!
    @IBOutlet var imgViewKuwait : UIImageView!

    @IBOutlet weak var lblChaneCountry: UILabel!
    @IBOutlet weak var lblChangeLanguage: UILabel!
    @IBOutlet weak var lblCountryName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        viewCountrySelect.layer.borderWidth = 2
        viewCountrySelect.layer.borderColor = UIColor.white.cgColor
        
    //    lblCountryName.text =
        
        self.lblCountryName.text = appDelegate.strCountry
        
        if appDelegate.strLanguage == "en"{
            
            lblChangeLanguage.text = "Change your language"
            lblChaneCountry.text = "Change your country"
            
            imgViewUsa.layer.borderWidth = 2
            imgViewUsa.layer.cornerRadius = imgViewUsa.frame.size.height/2
            imgViewUsa.layer.masksToBounds = true
            imgViewRussia.layer.borderWidth = 0
            imgViewKuwait.layer.borderWidth = 0
            
        }else if appDelegate.strLanguage == "ar"{
            
            lblChangeLanguage.text = "تغير لغة التطبيق"
            lblChaneCountry.text = "تغير الدولة"
            
            imgViewKuwait.layer.borderWidth = 2
            imgViewKuwait.layer.cornerRadius = imgViewKuwait.frame.size.height/2
            imgViewKuwait.layer.masksToBounds = true
            imgViewRussia.layer.borderWidth = 0
            imgViewUsa.layer.borderWidth = 0
            
        }else{
            
            lblChangeLanguage.text = "поменяй язык"
            lblChaneCountry.text = "изменить свою страну"
            
            imgViewRussia.layer.borderWidth = 2
            imgViewRussia.layer.cornerRadius = imgViewRussia.frame.size.height/2
            imgViewRussia.layer.masksToBounds = true
            imgViewKuwait.layer.borderWidth = 0
            imgViewUsa.layer.borderWidth = 0
        }
    }
    
    @IBAction func clickOnSelectLanguage(_ sender: Any) {
        
        let countryVC = self.storyboard?.instantiateViewController(withIdentifier: "CountrySelectViewController") as! CountrySelectViewController
        
        countryVC.delegate = self
        
        self.navigationController?.pushViewController(countryVC, animated: true)

    }
    
    func didFinishWithSuccessSelectCountry(dic: NSDictionary) {
        
  //      self.lblCountryName.text = dic.value(forKey: "name") as? String
        
        appDelegate.strCountry = dic.value(forKey: "name") as! String
        
        self.lblCountryName.text = appDelegate.strCountry
        
        UserDefaults.standard.set(appDelegate.strCountry, forKey: "name")
        UserDefaults.standard.synchronize()
        
        appDelegate.strCountryCode = dic.value(forKey: "abbr") as! String
        UserDefaults.standard.set(appDelegate.strCountryCode, forKey: "abbr")
        UserDefaults.standard.synchronize()

        
        self.navigationController?.popViewController(animated: true)
        
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        appDelegate.setupTabbarcontroller()
    }
    
    @IBAction func clickOnRussiaFlag(_ sender: Any) {
    
        imgViewRussia.layer.borderWidth = 2
        imgViewRussia.layer.cornerRadius = imgViewRussia.frame.size.height/2
        imgViewRussia.layer.masksToBounds = true
        imgViewKuwait.layer.borderWidth = 0
        imgViewUsa.layer.borderWidth = 0
        appDelegate.strLanguage = "ru"
        
        UserDefaults.standard.set(appDelegate.strLanguage, forKey: "lang")
        UserDefaults.standard.synchronize()

        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "languageChanged"), object: nil, userInfo: nil)
        
        appDelegate.setupTabbarcontroller()

        
    }
    
    @IBAction func clickOnUSFlag(_ sender: Any) {
    
        imgViewUsa.layer.borderWidth = 2
        imgViewUsa.layer.cornerRadius = imgViewUsa.frame.size.height/2
        imgViewUsa.layer.masksToBounds = true
        imgViewRussia.layer.borderWidth = 0
        imgViewKuwait.layer.borderWidth = 0
        appDelegate.strLanguage = "en"
        
        UserDefaults.standard.set(appDelegate.strLanguage, forKey: "lang")
        UserDefaults.standard.synchronize()
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "languageChanged"), object: nil, userInfo: nil)
        
        appDelegate.setupTabbarcontroller()

    }
    
    
    @IBAction func clickOnKuwaitFlag(_ sender: Any) {
    
        imgViewKuwait.layer.borderWidth = 2
        imgViewKuwait.layer.cornerRadius = imgViewKuwait.frame.size.height/2
        imgViewKuwait.layer.masksToBounds = true
        imgViewRussia.layer.borderWidth = 0
        imgViewUsa.layer.borderWidth = 0

        appDelegate.strLanguage = "ar"
        
        UserDefaults.standard.set(appDelegate.strLanguage, forKey: "lang")
        UserDefaults.standard.synchronize()
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "languageChanged"), object: nil, userInfo: nil)
        
        appDelegate.setupTabbarcontroller()


    }
    
}
