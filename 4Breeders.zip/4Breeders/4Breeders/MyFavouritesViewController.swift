//
//  MyFavouritesViewController.swift
//  4Breeders
//
//  Created by Rp on 07/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class MyFavouritesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout,responseDelegate {
    
    var arrFavourite = NSArray()
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.getFavouriteList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        //     self.navigationItem.title = "My Favourites"
        
        //      self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
        
    }
    
    func getFavouriteList(){
        
        let strParam = "lang=\(appDelegate.strLanguage)&mob_id=\(appDelegate.mobileId)"
        
        let strUrl = "http://4breeders.com/Api/Favouritelist/"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getFavouriteList", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                self.arrFavourite = Response.value(forKey: "data") as! NSArray
                print(self.arrFavourite)
                self.collectionView.reloadData()
            }
            
            
        }else{
            
        }
        
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrFavourite.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        let view = cell.contentView.viewWithTag(1000) as! UIView
        view.layer.cornerRadius = 5
        view.layer.masksToBounds = true
        
        let imgView = cell.contentView.viewWithTag(1002) as! UIImageView
        
        let lblDescription = cell.contentView.viewWithTag(1003) as! UILabel
        
        let dictFavourite = self.arrFavourite.object(at: indexPath.row) as! NSDictionary
        
        let strurlImg = dictFavourite.value(forKey: "image") as! String
        
        imgView.sd_setImage(with: URL.init(string: strurlImg), placeholderImage: nil, options: .continueInBackground, completed: nil)
        
        lblDescription.text = dictFavourite.value(forKey: "description") as? String
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let descriptionVc = self.storyboard?.instantiateViewController(withIdentifier: "DescriptionViewController") as! DescriptionViewController
        
        descriptionVc.dictAddDetails = self.arrFavourite.object(at: indexPath.row) as! NSDictionary
        
        descriptionVc.isfromFavourite = true
        
        self.navigationController?.pushViewController(descriptionVc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let size = CGSize.init(width: (UIScreen.main.bounds.size.width-30)/2, height: 220)
        
        return size
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets.init(top: 10, left: 5, bottom: 10, right: 5)
    }
    
}
