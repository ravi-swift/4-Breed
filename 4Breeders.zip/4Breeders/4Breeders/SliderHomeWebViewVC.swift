//
//  SliderHomeWebViewVC.swift
//  4Breeders
//
//  Created by Rp on 28/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit
import WebKit

class SliderHomeWebViewVC: UIViewController,WKNavigationDelegate {

    @IBOutlet weak var webViewSlider: WKWebView!
    @IBOutlet weak var viewWeb: UIView!
    
    var dictUrl = NSDictionary()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print(dictUrl)
        
        var strURL = dictUrl.value(forKey: "URL") as! String
        strURL = strURL.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        let request = URLRequest.init(url: URL.init(string: strURL)!)
        webViewSlider.navigationDelegate = self
        webViewSlider.load(request)
        
        viewWeb.layer.cornerRadius = 12
        viewWeb.layer.masksToBounds = true
    }
    

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        
        SVProgressHUD.show()
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        SVProgressHUD.dismiss()
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        
        SVProgressHUD.dismiss()
        
    }
    
}
