//
//  MyAdsViewController.swift
//  4Breeders
//
//  Created by Rp on 07/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class MyAdsViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout,responseDelegate,UIGestureRecognizerDelegate {
    
    var arrMyAds = NSArray()
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.postMyAds()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
//        self.navigationItem.title = "My Ads"
//        
//        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
        
    //    self.postMyAds()

    }
    
    func postMyAds(){
        
        let strParam = "lang=\(appDelegate.strLanguage)&mobile_id=\(appDelegate.mobileId)"
        
        let strUrl = "http://4breeders.com/Api/Myads/myads"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "postMyAds", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        if ServiceName == "postMyAds"
        {
            let result = "\(Response.value(forKey: "status") as! Int)"
            
            if result == "1"{
                
                DispatchQueue.main.async {
                    
                    self.arrMyAds = Response.value(forKey: "data") as! NSArray
                    print(self.arrMyAds)
                    self.collectionView.reloadData()
                }
                
                
            }else{
                
                DispatchQueue.main.async {
                    
                    self.arrMyAds = NSArray()
                    self.collectionView.reloadData()
                }
            }
        }else{
            
            let result = "\(Response.value(forKey: "status") as! Int)"
            
            if result == "1"{
                
                DispatchQueue.main.async {

                    self.postMyAds()
                }
                
                
            }else{
                
            }
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrMyAds.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
//        let view = cell.contentView.viewWithTag(1000) as! UIView
//        view.layer.cornerRadius = 5
//        view.layer.masksToBounds = true
        
        let imgView = cell.contentView.viewWithTag(1002) as! UIImageView
        //            imgView.layer.borderWidth = 1.5
        //            imgView.layer.borderColor = UIColor.init(red: 236/255, green: 103/255, blue: 90/255, alpha: 1).cgColor
        
        let lblDescription = cell.contentView.viewWithTag(1003) as! UILabel
        
        var imgTrash = cell.contentView.viewWithTag(1004) as! UIImageView
        
        imgTrash.image = imgTrash.image?.withRenderingMode(.alwaysTemplate)
        imgTrash.tintColor = UIColor.red
        
    //    let imgEdit = cell.contentView.viewWithTag(1005) as! UIImageView
        
        let dictMyAds = self.arrMyAds.object(at: indexPath.row) as! NSDictionary
        
        let strUrlimg = dictMyAds.value(forKey: "image") as! String
        
        imgView.sd_setImage(with: URL.init(string: strUrlimg), placeholderImage: nil, options: .continueInBackground, completed: nil)
        
        lblDescription.text = dictMyAds.value(forKey: "description") as? String
        
        let gestureTrash = UITapGestureRecognizer.init(target: self, action: #selector(tapOnTrash(gesture:)))
        gestureTrash.delegate = self
        imgTrash.isUserInteractionEnabled = true
        imgTrash.addGestureRecognizer(gestureTrash)
        
//        let gestureEdit = UITapGestureRecognizer.init(target: self, action: #selector(tapOnEdit(gesture:)))
//        gestureEdit.delegate = self
//        imgEdit.isUserInteractionEnabled = true
//        imgEdit.addGestureRecognizer(gestureEdit)
        
        return cell
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let size = CGSize.init(width: (UIScreen.main.bounds.size.width-30)/2, height: 220)
        
        return size
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets.init(top: 10, left: 5, bottom: 10, right: 5)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let adVC = self.storyboard?.instantiateViewController(withIdentifier: "AdsViewController") as! AdsViewController
        adVC.dicAdDetail = self.arrMyAds.object(at: indexPath.item) as! NSDictionary
        adVC.isFromEdit = true
        self.navigationController?.pushViewController(adVC, animated: true)
    }
    
    @objc func tapOnTrash(gesture:UITapGestureRecognizer){
        
        let dict = self.arrMyAds.object(at: 0) as! NSDictionary
        
        let strParam = "mobile_id=\(appDelegate.mobileId)&id=\(dict.value(forKey: "id") as! String)"
        
        let strUrl = "http://4breeders.com/Api/Deletesingleads"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "TrashData", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    @objc func tapOnEdit(gesture:UITapGestureRecognizer){
        
        
    }

}
