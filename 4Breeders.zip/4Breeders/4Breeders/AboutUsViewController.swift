//
//  AboutUsViewController.swift
//  4Breeders
//
//  Created by Rp on 07/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class AboutUsViewController: UIViewController,responseDelegate {

    @IBOutlet weak var txvDescription: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.getAboutData()
    }

    override func viewWillAppear(_ animated: Bool) {
        
//        self.navigationItem.title = "About Us"
//        
//        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
    }
    
    func getAboutData(){
        
        let strParam = "lang=\(appDelegate.strLanguage)"
        
        let strUrl = "http://4breeders.com/Api/About/aboutdetails"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getAboutData", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
        
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                let arrAbout = Response.value(forKey: "data") as! NSArray
                
                let dictAbout = arrAbout.object(at: 0) as! NSDictionary
                
                self.txvDescription.attributedText = (dictAbout.value(forKey: "description") as! String).html2AttributedString
                
                self.txvDescription.textAlignment = .right
            }
            
            
        }else{
            
        }
    }

}
