//
//  MakeBidOfferPopUpVC.swift
//  4Breeders
//
//  Created by Rp on 08/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class MakeBidOfferPopUpVC: UIViewController, UIGestureRecognizerDelegate, responseDelegate {
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewName: UIView!
    @IBOutlet weak var viewPrice: UIView!
    @IBOutlet weak var viewNumber: UIView!
    @IBOutlet weak var viewDescription: UIView!
    @IBOutlet weak var btnAddBid: UIButton!
    @IBOutlet weak var viewClose: UIView!
    
    @IBOutlet weak var txvDescription: UITextView!
    @IBOutlet weak var txtNumber: UITextField!
    @IBOutlet weak var txtPrice: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var lblStaticBidOffer: UILabel!
    
    var strId : String = ""
    
    var dictBids = NSDictionary()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        viewMain.layer.cornerRadius = 10
        viewMain.layer.masksToBounds = true
        
        viewClose.layer.cornerRadius = viewClose.frame.size.height/2
        viewClose.layer.masksToBounds = true
        
        btnAddBid.layer.cornerRadius = 5
        
        viewName.layer.cornerRadius = 5
        viewName.layer.borderWidth = 1
        viewName.layer.borderColor = UIColor.gray.cgColor
        viewPrice.layer.cornerRadius = 5
        viewPrice.layer.borderWidth = 1
        viewPrice.layer.borderColor = UIColor.gray.cgColor
        viewNumber.layer.cornerRadius = 5
        viewNumber.layer.borderWidth = 1
        viewNumber.layer.borderColor = UIColor.gray.cgColor
        viewDescription.layer.cornerRadius = 5
        viewDescription.layer.borderWidth = 1
        viewDescription.layer.borderColor = UIColor.gray.cgColor
        
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(tapOnViewClose(Gesture:)))
        tapGesture.delegate = self
        viewClose.isUserInteractionEnabled = true
        viewClose.addGestureRecognizer(tapGesture)
        
        if appDelegate.dictStaticWord.count > 0{
            
            txvDescription.placeholder = appDelegate.dictStaticWord.value(forKey: "Description") as! String
            //     lblStaticBidOffer.text = appDelegate.dictStaticWord.value(forKey: "Make Bid Offer") as! String
            txtNumber.placeholder = appDelegate.dictStaticWord.value(forKey: "Phone Number") as! String
            txtName.placeholder = appDelegate.dictStaticWord.value(forKey: "Name") as! String
            txtPrice.placeholder = appDelegate.dictStaticWord.value(forKey: "Price") as! String
            //     btnAddBid.setTitle(appDelegate.dictStaticWord.value(forKey: "Edit Bid") as! String, for: .normal)
        }
        
        if appDelegate.strLanguage == "en"
        {
            lblStaticBidOffer.text = "Make Bids"
            btnAddBid.setTitle("Submit", for: .normal)
            
        }else if appDelegate.strLanguage == "ar"
        {
            lblStaticBidOffer.text = "تقديم مزايدة"
            btnAddBid.setTitle("ارسال", for: .normal)
            
        }else{
            
            lblStaticBidOffer.text = "сделать ставку"
            btnAddBid.setTitle("Отправить", for: .normal)
        }
        
        print(dictBids)
    }
    
    func postComments(){
        
        let strParam = "lang=\(appDelegate.strLanguage)&phone=\(txtNumber.text!)&description=\(txvDescription.text!)&price=\(txtPrice.text! as! String)&name=\(txtName.text!)&post_id=\(strId)"
        
        let strUrl = "http://4breeders.com/Api/Comment"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "postComments", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        print(Response)
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                let controller = UIAlertController.init(title: "Message", message: "Comment Added Successfully!", preferredStyle: .alert)
                
                let actionOk = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
                    
                    self.dismiss(animated: true, completion: nil)
                    
                })
                
                controller.addAction(actionOk)
                
                self.present(controller, animated: true, completion: nil)
                
            }
        }else{
            
        }
        
    }
    
    @objc func tapOnViewClose(Gesture:UITapGestureRecognizer){
        
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func clickOnAddBid(_ sender: Any) {
        
        
        if txtPrice.text == ""{
            
            var controller = UIAlertController()
            
            if appDelegate.strLanguage == "en"
            {
             controller = UIAlertController.init(title: "Message", message: "Enter Price", preferredStyle: .alert)
                
            }else if appDelegate.strLanguage == "ar"
            {
                controller = UIAlertController.init(title: "Message", message: "السعر", preferredStyle: .alert)
                
            }else{
                
                controller = UIAlertController.init(title: "Message", message: "цена", preferredStyle: .alert)
            }
            
            let actionOk = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
                
                self.dismiss(animated: true, completion: nil)
                
            })
            
            controller.addAction(actionOk)
            
            self.present(controller, animated: true, completion: nil)
            
        }else{
            
            if dictBids.value(forKey: "price") as! String != ""{
                
                let startingPrice = (Int)(dictBids.value(forKey: "price") as! String)
                
                let enterPrice = (txtPrice.text as! NSString).integerValue
                
                if enterPrice >= startingPrice!
                {
                    
                    var controller = UIAlertController()
                    
                    if appDelegate.strLanguage == "en"
                    {
                        controller = UIAlertController.init(title: "Message", message: "Bid Price Update Successful", preferredStyle: .alert)
                    }
                    else if appDelegate.strLanguage == "ar"
                    {
                        controller = UIAlertController.init(title: "Message", message: "تم عمل المزايدة بنجاح", preferredStyle: .alert)
                    }
                    else{
                        
                        controller = UIAlertController.init(title: "Message", message: "Обновление цены предложения успешно", preferredStyle: .alert)
                    }
                    
                    let actionOk = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
                        
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UpdateComments"), object: nil, userInfo: nil)
                        
                        self.dismiss(animated: true, completion: nil)
                        
                    })
                    
                    controller.addAction(actionOk)
                    
                    self.present(controller, animated: true, completion: nil)
                    
                    
                    self.postComments()
                }
                else{
                    var controller = UIAlertController()
                    
                    if appDelegate.strLanguage == "en"
                    {
                        controller = UIAlertController.init(title: "Message", message: "Bid Price More then Starting Price", preferredStyle: .alert)
                        
                    }else if appDelegate.strLanguage == "ar"{
                        
                        controller = UIAlertController.init(title: "Message", message: "يرجى تغير سعر المزايدة لانه اعلى من سعر", preferredStyle: .alert)
                        
                    }else{
                        
                        controller = UIAlertController.init(title: "Message", message: "цена предложения больше, чем начальная цена", preferredStyle: .alert)
                    }
                    
                    let actionOk = UIAlertAction.init(title: "Ok", style: .destructive, handler: { (action) in
                        
                        self.dismiss(animated: true, completion: nil)
                        
                    })
                    
                    controller.addAction(actionOk)
                    
                    self.present(controller, animated: true, completion: nil)
                    
                }
                
            }else{
                
            }
        }
        
    }
}
