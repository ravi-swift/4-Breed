//
//  CountrySelectViewController.swift
//  4Breeders
//
//  Created by Rp on 21/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

protocol selectCountry {
    
    func didFinishWithSuccessSelectCountry(dic:NSDictionary)
}

class CountrySelectViewController: UIViewController, UITableViewDelegate,UITableViewDataSource, responseDelegate {
    
    var arrCountry = NSArray()
    
    var delegate : selectCountry!
    
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.getAllCountry()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.navigationBar.isHidden = false
        self.navigationController?.navigationBar.isTranslucent = false
        
        self.navigationItem.title = "Select Country"
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
        
        self.navigationController?.navigationBar.barTintColor = UIColor.init(red: 239/255, green: 101/255, blue: 90/255, alpha: 1)
        
        self.navigationController?.navigationBar.tintColor = UIColor.white
    }
    
    func getAllCountry(){
        
        let strParam = "lang=\(appDelegate.strLanguage)"
        
        let strUrl = "http://4breeders.com/Api/Country/get_country"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getAllCountry", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                self.arrCountry = Response.value(forKey: "data") as! NSArray
                print(self.arrCountry)
                self.tblView.reloadData()
            }
            
            
        }else{
            
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrCountry.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let lblCountry = cell.contentView.viewWithTag(1001) as! UILabel
        let lblCountryCode = cell.contentView.viewWithTag(1002) as! UILabel
        
        let dictCountry = self.arrCountry.object(at: indexPath.row) as! NSDictionary
        
        lblCountry.text = dictCountry.value(forKey: "name") as? String
        lblCountryCode.text = dictCountry.value(forKey: "abbr") as? String
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 40
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        delegate.didFinishWithSuccessSelectCountry(dic: arrCountry.object(at: indexPath.row) as! NSDictionary)
    }
}
