//
//  AdsViewController.swift
//  4Breeders
//
//  Created by Rp on 26/04/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class AdsViewController: UIViewController,UITextFieldDelegate,UITableViewDelegate,responseDelegate,UIGestureRecognizerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextViewDelegate {
    
    @IBOutlet weak var viewMobilenumber: UIView!
    @IBOutlet weak var viewCategory: UIView!
    @IBOutlet weak var viewSubCategory: UIView!
    @IBOutlet weak var viewTxvDescription: UIView!
    
    @IBOutlet weak var viewRecording: UIView!
    @IBOutlet weak var viewImg1: UIView!
    @IBOutlet weak var viewImg2: UIView!
    @IBOutlet weak var viewImg3: UIView!
    @IBOutlet weak var viewImg4: UIView!
    @IBOutlet weak var viewCheckMark: UIView!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var imgView1: UIImageView!
    @IBOutlet weak var imgView2: UIImageView!
    @IBOutlet weak var imgView3: UIImageView!
    @IBOutlet weak var imgView4: UIImageView!
    
    @IBOutlet weak var txtNumber: UITextField!
    @IBOutlet weak var txtCountryCode: UITextField!
    @IBOutlet weak var txtCategory: UITextField!
    @IBOutlet weak var txtSubCategory: UITextField!
    @IBOutlet weak var imgViewDownArrow: UIImageView!
    @IBOutlet weak var txvDescription: UITextView!
    
    @IBOutlet weak var imgViewCheckMark: UIImageView!
    
    @IBOutlet weak var lblImgNvideoStatic: UILabel!
    
    @IBOutlet weak var lblStaticVerify: UILabel!
    let dropDownCategory = DropDown()
    let dropDownSubCategory = DropDown()
    
    var strCategoryId : String = ""
    var strSubCategoryId : String = ""
    var videoData : NSData?
    var arrImageData = NSMutableArray()
    var isFromEdit : Bool = false
    var dicAdDetail : NSDictionary!
    
    lazy var dropDowns: [DropDown] = {
        return [
            
            self.dropDownCategory,
            self.dropDownSubCategory
            
        ]
    }()
    
    
    var arrCategory = NSArray()
    var arrSubCategory = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        viewRedious(view: viewMobilenumber)
        viewRedious(view: viewCategory)
        viewRedious(view: viewSubCategory)
        viewRedious(view: viewTxvDescription)
        
        viewRediousCircle(view: viewRecording)
        viewRediousCircle(view: viewImg1)
        viewRediousCircle(view: viewImg2)
        viewRediousCircle(view: viewImg3)
        viewRediousCircle(view: viewImg4)
        
        viewCheckMark.layer.borderColor = UIColor.black.cgColor
        viewCheckMark.layer.borderWidth = 1.5
        
        btnSubmit.layer.cornerRadius = 8
        btnSubmit.layer.borderWidth = 1.5
        btnSubmit.layer.borderColor = UIColor.black.cgColor
        
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(tapOnTapgesture(gesture:)))
        tapGesture.delegate = self
        viewImg1.isUserInteractionEnabled = true
        viewImg1.addGestureRecognizer(tapGesture)
        
        let tapGesture2 = UITapGestureRecognizer.init(target: self, action: #selector(tapOnTapgesture(gesture:)))
        tapGesture2.delegate = self
        viewImg2.isUserInteractionEnabled = true
        viewImg2.addGestureRecognizer(tapGesture2)
        
        let tapGesture3 = UITapGestureRecognizer.init(target: self, action: #selector(tapOnTapgesture(gesture:)))
        tapGesture3.delegate = self
        viewImg3.isUserInteractionEnabled = true
        viewImg3.addGestureRecognizer(tapGesture3)
        
        let tapGesture4 = UITapGestureRecognizer.init(target: self, action: #selector(tapOnTapgesture(gesture:)))
        tapGesture4.delegate = self
        viewImg4.isUserInteractionEnabled = true
        viewImg4.addGestureRecognizer(tapGesture4)
        
        let tapGestureChackMark = UITapGestureRecognizer.init(target: self, action: #selector(taponCheckMark(gesture:)))
        tapGestureChackMark.delegate = self
        imgViewCheckMark.isUserInteractionEnabled = true
        imgViewCheckMark.addGestureRecognizer(tapGestureChackMark)

        self.getCategoryList()
        
        if self.isFromEdit{
            self.setupDetail()
        }
        
        txvDescription.placeholderColor = UIColor.gray
        txvDescription.textAlignment = .right
        
        if appDelegate.dictStaticWord.count > 0{
            
            txtNumber.placeholder = appDelegate.dictStaticWord.value(forKey: "Mobile Number") as! String
            txtCategory.placeholder = appDelegate.dictStaticWord.value(forKey: "categeory") as! String
            txtSubCategory.placeholder = appDelegate.dictStaticWord.value(forKey: "subcategeory") as! String
            txvDescription.placeholder = appDelegate.dictStaticWord.value(forKey: "description") as! String
            lblImgNvideoStatic.text = appDelegate.dictStaticWord.value(forKey: "Image Text") as! String
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(languageChangedDone), name: NSNotification.Name(rawValue: "languageChanged"), object: nil)
        
    }
    
    func setupDetail()
    {
        btnSubmit.setTitle("Update", for: .normal)
        
        self.txtNumber.text = self.dicAdDetail.value(forKey: "phone") as? String
        self.txtCategory.text = self.dicAdDetail.value(forKey: "catname") as? String
        self.txtSubCategory.text = self.dicAdDetail.value(forKey: "Subcat") as? String
        self.txvDescription.text = self.dicAdDetail.value(forKey: "description") as? String
        
        self.strCategoryId = (self.dicAdDetail.value(forKey: "category_id") as? String)!
        self.strSubCategoryId = (self.dicAdDetail.value(forKey: "subcategory_id") as? String)!

        self.imgView1.sd_setImage(with: URL.init(string: self.dicAdDetail.value(forKey: "image") as! String), placeholderImage: UIImage.init(named: "plus-img"), options: .continueInBackground)
        
        if !(self.dicAdDetail.value(forKey: "key") as! AnyObject).isKind(of: NSNull.self)
        
        {
         
            let arrayKey = self.dicAdDetail.value(forKey: "key") as! NSArray
            
            for index in 0..<arrayKey.count{
                
                let strImage = "http:sachinsam.com/4breeders/attachments/shop_images/\(arrayKey.object(at: index))"
                
                if index == 0{
                    self.imgView2.sd_setImage(with: URL.init(string: strImage), placeholderImage: UIImage.init(named: "plus-img"), options: .continueInBackground)
                    
                }
                else if index == 1{
                    self.imgView3.sd_setImage(with: URL.init(string: strImage), placeholderImage: UIImage.init(named: "plus-img"), options: .continueInBackground)
                }
                else{
                    self.imgView4.sd_setImage(with: URL.init(string: strImage), placeholderImage: UIImage.init(named: "plus-img"), options: .continueInBackground)
                }
            }

        }

    }
    
    func setUpDropDown(dropDown:DropDown,arrOption:[String])
    {
        dropDown.anchorView = viewCategory
        
        dropDown.bottomOffset = CGPoint(x: 0, y: 0)
        
        dropDown.dataSource = arrOption
        
        dropDown.selectionAction = { [weak self] (index, item) in
            
            self!.txtCategory.text = item
            
            self?.strCategoryId = (self?.arrCategory.object(at: index) as! NSDictionary).value(forKey: "id") as! String
            
            self?.getSubCategory()
            
        }
    }
    
    func setUpDropDownSubCategory(dropDown:DropDown,arrOption:[String])
    {
        dropDown.anchorView = viewSubCategory
        
        dropDown.bottomOffset = CGPoint(x: 0, y: 0)
        
        dropDown.dataSource = arrOption
        
        dropDown.selectionAction = { [weak self] (index, item) in
            
            self!.txtSubCategory.text = item
            
            self?.strSubCategoryId = (self?.arrSubCategory.object(at: index) as! NSDictionary).value(forKey: "id") as! String
            
            
        }
    }
    
    func getSubCategory(){
        
        
        let strParam = "lang=\(appDelegate.strLanguage)&shop_categorie=\(self.strCategoryId)"
        
        let strUrl = "http://4breeders.com/Api/Categeorysublist/getcategeory"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getSubCategory", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func getCategoryList(){
        
        let strParam = "lang=\(appDelegate.strLanguage)"
        
        let strUrl = "http://4breeders.com/Api/Categeory/getcategeory"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getCategoryList", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        print(Response)
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                if ServiceName == "getSubCategory"{
                    
                    self.arrSubCategory = Response.value(forKey: "data") as! NSArray
                    print(self.arrCategory)
                    
                    let arrTitle = self.arrSubCategory.value(forKey: "title") as! NSArray
                    
                    self.setUpDropDownSubCategory(dropDown: self.dropDownSubCategory, arrOption: arrTitle as! [String])
                    
                    
                }else if ServiceName == "getCategoryList"{
                    
                    self.arrCategory = Response.value(forKey: "data") as! NSArray
                    print(self.arrCategory)
                    
                    let arrTitle = self.arrCategory.value(forKey: "title") as! NSArray
                    
                    self.setUpDropDown(dropDown: self.dropDownCategory, arrOption: arrTitle as! [String])
                    
                }
                
                
            }
            
            
        }else{
            
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
    
        self.navigationItem.title = "4BREEDERS"
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
        
        if UIScreen.main.bounds.size.height > 667
        {
            let imgView = UIImageView()
            imgView.frame = CGRect.init(x: 0, y: -20, width: UIScreen.main.bounds.size.width, height: 64)
            imgView.image = UIImage.init(named: "header-bg-w-background")
            
            self.navigationController?.navigationBar.insertSubview(imgView, at: 1)
        }
        else{
            self.navigationController?.navigationBar.setBackgroundImage(UIImage.init(named: "header-bg-w-background"), for: .default)
            
        }
        
        if appDelegate.strLanguage == "en"{
            
            btnSubmit.setTitle("Submit", for: .normal)
            
            lblStaticVerify.text = "Please agree to the Terms and Conditions"
            
            var img = UIImage.init(named: "usa_flag")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else if appDelegate.strLanguage == "ru"{
            
            btnSubmit.setTitle("Отправить", for: .normal)
            
            lblStaticVerify.text = "Пожалуйста, согласитесь с Условиями перед "
            
            var img = UIImage.init(named: "russia_flagSmall")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else{
            
            btnSubmit.setTitle("ارسال", for: .normal)
            
            lblStaticVerify.text = "يرجى الموافقة على الشروط والاحكام قبل النشر"
            
            var img = UIImage.init(named: "kuwait_flagSmall")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
        }
        
        self.txtCountryCode.text = appDelegate.strCountryCode
        
        
        let rightBarBtn = UIBarButtonItem.init(image: UIImage.init(named: "search_icon"), style: .plain, target: self, action: #selector(clickOnRightBarBtn(btn:)))
        self.navigationItem.rightBarButtonItem = rightBarBtn

        NotificationCenter.default.addObserver(self, selector: #selector(languageChangedDone), name: NSNotification.Name(rawValue: "languageChanged"), object: nil)
        
        self.navigationController?.navigationBar.isTranslucent = false
    }
    
    @objc func languageChangedDone(){
        
        if appDelegate.dictStaticWord.count > 0{
            
            txtNumber.placeholder = appDelegate.dictStaticWord.value(forKey: "Mobile Number") as! String
            txtCategory.placeholder = appDelegate.dictStaticWord.value(forKey: "categeory") as! String
            txtSubCategory.placeholder = appDelegate.dictStaticWord.value(forKey: "subcategeory") as! String
            txvDescription.placeholder = appDelegate.dictStaticWord.value(forKey: "description") as! String
            lblImgNvideoStatic.text = appDelegate.dictStaticWord.value(forKey: "Image Text") as! String
        }
        
        self.getCategoryList()
    }

    
    func viewRedious(view:UIView){
        
        view.layer.cornerRadius = 5
        view.layer.borderColor = UIColor.groupTableViewBackground.cgColor
        view.layer.borderWidth = 1.5
        view.layer.masksToBounds = true
    }
    
    func viewRediousCircle(view:UIView){
        
        view.layer.cornerRadius = view.frame.size.height/2
        view.layer.masksToBounds = true
    }
    
    func cameraOption(){
        
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if picker.mediaTypes == ["public.movie"]{
            
            let videoUrl = info[UIImagePickerController.InfoKey.mediaURL]
            
            do{
                self.videoData = try NSData.init(contentsOf: videoUrl as! URL)
            }
            catch{
                
            }
            
        }else{

            if let chosenImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
                
                if picker.accessibilityValue == "1001"{
                    
                    imgView1.contentMode = .scaleAspectFill
                    imgView1.image = chosenImage
                    
                }
                else if picker.accessibilityValue == "1002"
                {
                    imgView2.contentMode = .scaleAspectFill
                    imgView2.image = chosenImage
                    self.arrImageData.add(imgView2.image?.pngData())
                    
                }else if picker.accessibilityValue == "1003"
                {
                    imgView3.contentMode = .scaleAspectFill
                    imgView3.image = chosenImage
                    self.arrImageData.add(imgView3.image?.pngData())
                    
                    
                }else if picker.accessibilityValue == "1004"{
                    
                    imgView4.contentMode = .scaleAspectFill
                    imgView4.image = chosenImage
                    self.arrImageData.add(imgView4.image?.pngData())
                    
                }
                
            } else{
                
                let chosenImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
                
                if picker.accessibilityValue == "1001"{
                    
                    imgView1.contentMode = .scaleAspectFill
                    imgView1.image = chosenImage
                    
                }
                else if picker.accessibilityValue == "1002"
                {
                    imgView2.contentMode = .scaleAspectFill
                    imgView2.image = chosenImage
                    self.arrImageData.add(imgView2.image?.pngData())
                    
                }else if picker.accessibilityValue == "1003"
                {
                    imgView3.contentMode = .scaleAspectFill
                    imgView3.image = chosenImage
                    self.arrImageData.add(imgView3.image?.pngData())
                    
                    
                }else if picker.accessibilityValue == "1004"{
                    
                    imgView4.contentMode = .scaleAspectFill
                    imgView4.image = chosenImage
                    self.arrImageData.add(imgView4.image?.pngData())
                    
                }
                
            }
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    @objc func tapOnTapgesture(gesture:UITapGestureRecognizer){
        
        let tag = gesture.view?.tag as! Int
        
        let controller = UIAlertController.init(title: "Select Photos", message: nil, preferredStyle: .actionSheet)
        
        let actionLibrary = UIAlertAction.init(title: "Camera", style: .default) { (action) in
            
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                var imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .camera
                imagePicker.allowsEditing = false
                imagePicker.accessibilityValue = "\(tag)"
                self.present(imagePicker, animated: true, completion: nil)
            }
        }
        
        controller.addAction(actionLibrary)
        
        let actionGallery = UIAlertAction.init(title: "Gallery", style: .default) { (action) in
            
            if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
                var imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .photoLibrary;
                imagePicker.allowsEditing = true
                imagePicker.accessibilityValue = "\(tag)"
                self.present(imagePicker, animated: true, completion: nil)
            }
        }
        
        controller.addAction(actionGallery)
        
        let actioncancle = UIAlertAction.init(title: "Cancel", style: .destructive) { (action) in
            
            controller.dismiss(animated: true, completion: nil)
        }
        
        controller.addAction(actioncancle)
        
        self.present(controller, animated: true, completion: nil)
        
        
    }
    
    @IBAction func clickOnVideo(_ sender: Any) {
        
        let controller = UIAlertController.init(title: "Select", message: nil, preferredStyle: .actionSheet)
        
        let actionLibrary = UIAlertAction.init(title: "select video", style: .default) { (action) in
            
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.mediaTypes = ["public.movie"]
            self.present(picker, animated: true, completion: nil)
        }
        
        controller.addAction(actionLibrary)
        
        let actionCapture = UIAlertAction.init(title: "capture video", style: .default) { (action) in
            
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .camera
            picker.mediaTypes = ["public.movie"]
            self.present(picker, animated: true, completion: nil)
        }
        
        controller.addAction(actionCapture)
        
        let actioncancle = UIAlertAction.init(title: "Cancel", style: .destructive) { (action) in
            
            controller.dismiss(animated: true, completion: nil)
        }
        
        controller.addAction(actioncancle)
        
        
        self.present(controller, animated: true, completion: nil)
    }
    
    
    @objc func clickOnLeftBarBtn(btn:UIButton){
        
        let settingVC = self.storyboard?.instantiateViewController(withIdentifier: "SeetingViewController") as! SeetingViewController
        
        self.navigationController?.pushViewController(settingVC, animated: true)
    }
    
    @objc func clickOnRightBarBtn(btn:UIButton){
        
        let searchVC = self.storyboard?.instantiateViewController(withIdentifier: "SearchBarViewController") as! SearchBarViewController
        
        self.navigationController?.pushViewController(searchVC, animated: true)
    }
    
    
    func editAds()
    {
        if txtNumber.text! == ""
        {
            self.showAlertMessage(strMessage: "Please enter phone number")
        }
        else if strCategoryId == ""
        {
            self.showAlertMessage(strMessage: "Please select category")
        }
        else if strSubCategoryId == ""
        {
            self.showAlertMessage(strMessage: "Please select subcategory")
        }
        else if txvDescription.text! == ""
        {
            self.showAlertMessage(strMessage: "Please enter description")
        }
        else{
        self.arrImageData.removeAllObjects()
        
        self.arrImageData.add(self.imgView2.image?.pngData())
        self.arrImageData.add(self.imgView3.image?.pngData())
        self.arrImageData.add(self.imgView4.image?.pngData())
        
        SVProgressHUD.show()
        
        let myUrl = NSURL(string: "http://4breeders.com/Api/Editads/Editads");
        
        let request = NSMutableURLRequest(url:myUrl! as URL);
        request.httpMethod = "POST";
        
        let boundary = generateBoundaryString()
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        let parameters = [
            "abbr"  : appDelegate.strLanguage,
            "country" : appDelegate.strCountryCode,
            "phone"    : "\(txtNumber.text!)",
            "description" : "\(txvDescription.text!)",
            "shop_categorie" : strCategoryId,
            "subcat_id" : strSubCategoryId,
            "mobile_id" : appDelegate.mobileId,
            "id":dicAdDetail.value(forKey: "id") as! String
            ] as [String : Any]
        
        request.httpBody = createBodyWithParameters(parameters: parameters as? [String : String], filePathKey: "image_url", boundary: boundary) as Data
        
        let task = URLSession.shared.dataTask(with: request as URLRequest)
        {
            data, response, error in
            
            DispatchQueue.main.async(execute: {
                
                SVProgressHUD.dismiss()
            });
            
            if error != nil
            {
                print("******** error=\(error)")
                return
            }
            
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("\(responseString!)")
            
            do
            {
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary
                print(json!)
                
                if json?.value(forKey: "status") as! Int == 1
                {
                    DispatchQueue.main.async(execute: {
                        
                        let controller = UIAlertController.init(title: "4Breeders", message: "Ads Edit Successfully", preferredStyle: .alert)
                        
                        let actionOk = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
                            
                            controller.dismiss(animated: true, completion: nil)
                            
                        })
                        
                        controller.addAction(actionOk)
                        
                        self.present(controller, animated: true, completion: nil)
                        
                    })
                }
                
            }
            catch
            {
                print("\n\n*************ERROR******** => \(error)\n\n")
            }
            
        }
        
        task.resume()
        }
    }
    
    @IBAction func clickOnSubmit(_ sender: Any) {
        
        if self.isFromEdit{
            self.editAds()
        }
        else{
            
            if imgViewCheckMark.image == UIImage.init(named: "checked-icon")
            {
                if txtNumber.text! == ""
                {
                    self.showAlertMessage(strMessage: "Please enter phone number")
                }
                else if strCategoryId == ""
                {
                    self.showAlertMessage(strMessage: "Please select category")
                }
                else if strSubCategoryId == ""
                {
                    self.showAlertMessage(strMessage: "Please select subcategory")
                }
                else if txvDescription.text! == ""
                {
                    self.showAlertMessage(strMessage: "Please enter description")
                }
                else{
                SVProgressHUD.show()
                
                let myUrl = NSURL(string: "http://4breeders.com/Api/Addads/addads");
                
                let request = NSMutableURLRequest(url:myUrl! as URL);
                request.httpMethod = "POST";
                
                let boundary = generateBoundaryString()
                
                request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
                
                let parameters = [
                    "abbr"  : appDelegate.strLanguage,
                    "country" : appDelegate.strCountryCode,
                    "phone"    : "\(txtNumber.text!)",
                    "description" : "\(txvDescription.text!)",
                    "shop_categorie" : strCategoryId,
                    "subcat_id" : strSubCategoryId,
                    "mobile_id" : appDelegate.mobileId,
                    ] as [String : Any]
                
                request.httpBody = createBodyWithParameters(parameters: parameters as? [String : String], filePathKey: "image_url", boundary: boundary) as Data
                
                let task = URLSession.shared.dataTask(with: request as URLRequest)
                {
                    data, response, error in
                    
                    DispatchQueue.main.async(execute: {
                        
                        SVProgressHUD.dismiss()
                    });
                    
                    if error != nil
                    {
                        print("******** error=\(error)")
                        return
                    }
                    
                    let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    print("\(responseString!)")
                    
                    do
                    {
                        let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary
                        print(json!)
                        
                        if json?.value(forKey: "status") as! Int == 1
                        {
                            DispatchQueue.main.async(execute: {
                                
                                var controller = UIAlertController()
                                
                                if appDelegate.strLanguage == "en"
                                {
                                     controller = UIAlertController.init(title: "4Breeders", message: "Your ads is submit please waiting approval", preferredStyle: .alert)
                                    
                                }else if appDelegate.strLanguage == "ar"
                                {
                                     controller = UIAlertController.init(title: "4Breeders", message: "تم اضافة اعلانك يرجى الانتظار موافقة", preferredStyle: .alert)
                                    
                                }else{
                                    
                                     controller = UIAlertController.init(title: "4Breeders", message: "Ваши объявления отправлены, пожалуйста, ожидая подтверждения", preferredStyle: .alert)
                                }
                                
                                let actionOk = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
                                    
                                    self.txtNumber.text = ""
                                    self.txtCategory.text = ""
                                    self.txtSubCategory.text = ""
                                    self.strCategoryId = ""
                                    self.strSubCategoryId = ""
                                    self.txvDescription.text = ""
                                    self.imgView1.image = UIImage.init(named: "plus-img")
                                    self.imgView2.image = UIImage.init(named: "plus-img")
                                    self.imgView3.image = UIImage.init(named: "plus-img")
                                    self.imgView4.image = UIImage.init(named: "plus-img")
                                    self.videoData = NSData()
                                    self.arrImageData.removeAllObjects()
                                    
                                    controller.dismiss(animated: true, completion: nil)
                                    
                                })
                                
                                controller.addAction(actionOk)
                                
                                self.present(controller, animated: true, completion: nil)
                                
                                self.imgViewCheckMark.image = UIImage.init(named: "unchecked-icon")
                            })
                        }
                        
                    }
                    catch
                    {
                        print("\n\n*************ERROR******** => \(error)\n\n")
                    }
                    
                }
                
                task.resume()
                }
            }else{
                
                let controller = UIAlertController.init(title: "Message", message: "Please check to verify", preferredStyle: .alert)
                
                let actionOk = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
                    
                    self.dismiss(animated: true, completion: nil)
                    
                })
                
                controller.addAction(actionOk)
                
                self.present(controller, animated: true, completion: nil)
            }
        
        }
    }
    
    func showAlertMessage(strMessage:String)
    {
        let controller = UIAlertController.init(title: "4Breeders", message: strMessage, preferredStyle: .alert)
        
        let actionOk = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
            
            self.dismiss(animated: true, completion: nil)
            
        })
        
        controller.addAction(actionOk)
        
        self.present(controller, animated: true, completion: nil)
    }
    
    func generateBoundaryString() -> String {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    func createBodyWithParameters(parameters: [String: String]?, filePathKey: String!, boundary: String) -> NSData {
        let body = NSMutableData();
        
        if parameters != nil {
            for (key, value) in parameters! {
                body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
                body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: String.Encoding.utf8)!)
                body.append("\(value)\r\n".data(using: String.Encoding.utf8)!)
                
            }
        }
        
        let filename = "image.jpg"
        let mimetype = "image/jpg"
        
        let imageData = imgView1.image?.pngData()
        
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Disposition: form-data; name=image; filename=\"\(filename)\"\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.utf8)!)
        body.append(imageData as! Data)
        body.append("\r\n".data(using: String.Encoding.utf8)!)
        body.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
        
        for index in 0..<arrImageData.count
        {
            let filename = "image\(index+1).jpg"
            
            let imageData = arrImageData.object(at: index)
            
            body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Disposition: form-data; name=key[]; filename=\"\(filename)\"\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.utf8)!)
            body.append(imageData as! Data)
            body.append("\r\n".data(using: String.Encoding.utf8)!)
            body.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
        }
        
        if videoData != nil{
            
            let filenameVideo = "upload.mov"
            let mimetypeVideo = "video/mov"
            
            body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Disposition: form-data; name=video; filename=\"\(filenameVideo)\"\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Type: \(mimetypeVideo)\r\n\r\n".data(using: String.Encoding.utf8)!)
            body.append(videoData as! Data)
            body.append("\r\n".data(using: String.Encoding.utf8)!)
            body.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
        }
      
        return body
    }
    
    @IBAction func clickOnViewCategory(sender:UIButton)
    {
        self.dropDownCategory.show()
    }
    
    @IBAction func clickOnSubCategory(sender:UIButton)
    {
        self.dropDownSubCategory.show()
    }
    
    @objc func taponCheckMark(gesture:UITapGestureRecognizer){
        
        if imgViewCheckMark.image == UIImage.init(named: "unchecked-icon")
        {
            imgViewCheckMark.image = UIImage.init(named: "checked-icon")
            
        }else{
            
            imgViewCheckMark.image = UIImage.init(named: "unchecked-icon")
        }
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
     //   textField.resignFirstResponder()
        
        return true
    }
    
//    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
//
//        if text == "\n" {
//
//            textView.resignFirstResponder()
//        }
//
//        return true
//    }
    

}
