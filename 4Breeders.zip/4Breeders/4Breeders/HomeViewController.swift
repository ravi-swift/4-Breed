//
//  HomeViewController.swift
//  4Breeders
//
//  Created by Rp on 26/04/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITableViewDelegate, UITableViewDataSource, responseDelegate, JOLImageSliderDelegate {
    
    @IBOutlet weak var viewSliderImg: UIView!
 //   @IBOutlet var collectionViewTop : UICollectionView!
    
    @IBOutlet weak var pageControl: UIPageControl!
    
    @IBOutlet weak var tblView: UITableView!
    
    var arrSlider = NSArray()
    var arrCategory = NSArray()
    var arrCategoryBottom = NSArray()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.getCategory()
        self.getCategoryBottom()
        self.getSliderimg()
        
        NotificationCenter.default.addObserver(self, selector: #selector(realodData), name: NSNotification.Name(rawValue: "reloadCategory"), object: nil)
    }
    
    @objc func realodData()
    {
        self.tblView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationItem.title = "4BREEDERS"
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
        
        if UIScreen.main.bounds.size.height > 667
        {
            let imgView = UIImageView()
            imgView.frame = CGRect.init(x: 0, y: -20, width: UIScreen.main.bounds.size.width, height: 64)
            imgView.image = UIImage.init(named: "header-bg-w-background")
            
            self.navigationController?.navigationBar.insertSubview(imgView, at: 1)
        }
        else{
            self.navigationController?.navigationBar.setBackgroundImage(UIImage.init(named: "header-bg-w-background"), for: .default)

        }
        
        if appDelegate.strLanguage == "en"{
            
            var img = UIImage.init(named: "usa_flag")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else if appDelegate.strLanguage == "ru"{
            
            var img = UIImage.init(named: "russia_flagSmall")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else{
            
            var img = UIImage.init(named: "kuwait_flagSmall")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
        }
        
        let rightBarBtn = UIBarButtonItem.init(image: UIImage.init(named: "search_icon"), style: .plain, target: self, action: #selector(clickOnRightBarBtn(btn:)))
        self.navigationItem.rightBarButtonItem = rightBarBtn
        
        NotificationCenter.default.addObserver(self, selector: #selector(languageChangedDone), name: NSNotification.Name(rawValue: "languageChanged"), object: nil)
        
        self.navigationController?.navigationBar.isTranslucent = false
    }
    
    @objc func languageChangedDone(){
        
        self.getCategory()
        self.getCategoryBottom()
        self.getSliderimg()
    }
    
    func getSliderimg(){
        
        let strParam = "lang=\(appDelegate.strLanguage)"
        
        let strUrl = "http://4breeders.com/Api/Slider"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getSliderimg", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func getCategory(){
        
        let strParam = "lang=\(appDelegate.strLanguage)"
        
        let strUrl = "http://4breeders.com/Api/Specialcat/getspecialCat"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getCategoryTop", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func getCategoryBottom(){
        
        let strParam = "lang=\(appDelegate.strLanguage)"
        
        let strUrl = "http://4breeders.com/Api/Categeorylist"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getCategoryBottom", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }

    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        if ServiceName == "getCategoryTop"
        {
            let result = "\(Response.value(forKey: "status") as! Int)"
            
            if result == "1"{
                
                DispatchQueue.main.async {
                    
                    self.arrCategory = Response.value(forKey: "data") as! NSArray
                    print(self.arrCategory)
                    self.tblView.reloadData()
                }
                
                
            }else{
                
            }

        }else if ServiceName == "getCategoryBottom"{
            
            let result = "\(Response.value(forKey: "status") as! Int)"
            
            if result == "1"{
                
                DispatchQueue.main.async {
                    
                    self.arrCategoryBottom = Response.value(forKey: "data") as! NSArray
                    self.tblView.reloadData()
                }
                
                
            }else{
                
            }
        }else{
            
            let result = "\(Response.value(forKey: "status") as! Int)"
            
            if result == "1"{
                
                DispatchQueue.main.async {
                    
                    self.arrSlider = Response.value(forKey: "data") as! NSArray
                    print(self.arrSlider)
                    self.pageControl.numberOfPages = self.arrSlider.count
          //          self.collectionViewTop.reloadData()
                    
                    let arraySlider = NSMutableArray()
                    
                    for index in 0..<self.arrSlider.count{
                        
                        let dic = self.arrSlider.object(at: index) as! NSDictionary
                        
                        let slide = JOLImageSlide()
                        slide.image = dic.value(forKey: "image") as? String
                        arraySlider.add(slide)
                        
                    }
                    
                    let imageSlider = JOLImageSlider.init(frame: CGRect.init(x: 0, y: 0, width: (self.viewSliderImg.frame.size.width), height:self.viewSliderImg.frame.size.height), andSlides: arraySlider as! [Any])
                    imageSlider?.autoSlide = true
                    imageSlider?.delegate = self
                    self.viewSliderImg.addSubview(imageSlider!)

                }
                
            }else{
                
            }
        }
    }
    
    func imagePager(_ imagePager: JOLImageSlider!, didSelectImageAt index: UInt) {
        
        let sliderWebVC = self.storyboard?.instantiateViewController(withIdentifier: "SliderHomeWebViewVC") as! SliderHomeWebViewVC
        
        sliderWebVC.dictUrl = self.arrSlider.object(at: Int(index)) as! NSDictionary
        
        self.navigationController?.pushViewController(sliderWebVC, animated: true)
    }

    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let collectionView = cell.contentView.viewWithTag(1001) as! UICollectionView
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.accessibilityValue = "\(indexPath.section)"
        
        collectionView.reloadData()
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if section == 0{
            
            let headerView = UIView.init(frame: CGRect.init(x: 10, y: 5, width: UIScreen.main.bounds.size.width-20, height: 21))
            
            let lblTitle = UILabel()
            lblTitle.frame = CGRect.init(x: 10, y: 0, width: UIScreen.main.bounds.size.width-30, height: 21)
            if appDelegate.dictStaticWord.count > 0{
                lblTitle.text = appDelegate.dictStaticWord.value(forKey: "First Categeory Text") as? String

            }
            lblTitle.textAlignment = .right
            lblTitle.textColor = UIColor.init(red: 236/255, green: 103/255, blue: 90/255, alpha: 1)
            lblTitle.font = UIFont.systemFont(ofSize: 17)
            
            headerView.addSubview(lblTitle)
            
            return headerView
            
        }else{
            
            let headerView = UIView.init(frame: CGRect.init(x: 10, y: 5, width: UIScreen.main.bounds.size.width-20, height: 21))
            
            let lblTitle = UILabel()
            lblTitle.frame = CGRect.init(x: 10, y: 0, width: UIScreen.main.bounds.size.width-30, height: 21)
            if appDelegate.dictStaticWord.count > 0 {
                lblTitle.text = appDelegate.dictStaticWord.value(forKey: "second Categeory Text") as? String

            }
            lblTitle.textAlignment = .right
            lblTitle.textColor = UIColor.init(red: 236/255, green: 103/255, blue: 90/255, alpha: 1)
            lblTitle.font = UIFont.systemFont(ofSize: 17)
            
            headerView.addSubview(lblTitle)
            
            return headerView
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 21
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        let widthCollection = (UIScreen.main.bounds.size.width-20)/95
        
        let numberOfItems = arrCategory.count
        
        if numberOfItems <= 4{
            
            return 110
            
        }else{
            
            let row = (CGFloat)(numberOfItems)/widthCollection
            
            let height = 110 * (ceil)(row)
            
            return height
        }
        
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        if collectionView == collectionViewTop{
//
//            return arrSlider.count
//
//        }else{
        
            if collectionView.accessibilityValue == "0"{
                
                return arrCategory.count
            }
            else{
                
                return arrCategoryBottom.count
            }
            
 //       }
    }
    

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
//        if collectionView == collectionViewTop{
//
//            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
//
//            let imgView = cell.contentView.viewWithTag(1001) as! UIImageView
//
//            let dictSlider = self.arrSlider.object(at: indexPath.item) as! NSDictionary
//
//            let strUrlImg = dictSlider.value(forKey: "image") as! String
//
//            imgView.sd_setImage(with: URL.init(string: strUrlImg), placeholderImage: nil, options: .continueInBackground, completed: nil)
//
//            return cell
//
//        }else{
        
            if collectionView.accessibilityValue == "0"{
                
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
                
                //            let arrImg = [UIImage.init(named: "horse"),UIImage.init(named: "tortoise"),UIImage.init(named: "birdCat"),UIImage.init(named: "horse"),UIImage.init(named: "fish"),UIImage.init(named: "fish"),UIImage.init(named: "fish"),UIImage.init(named: "fish")]
                
                let imgViewBg = cell.contentView.viewWithTag(1001) as! UIImageView
                imgViewBg.layer.cornerRadius = 8
                
                let imgViewImg = cell.contentView.viewWithTag(1003) as! UIImageView
                let lblTitle = cell.contentView.viewWithTag(1002) as! UILabel
                
                let dictCategory = self.arrCategory.object(at: indexPath.item) as! NSDictionary
                
                print(dictCategory)
                
                lblTitle.text = dictCategory.value(forKey: "title") as! String
                
                let strUrl = dictCategory.value(forKey: "image") as! String
                
                imgViewImg.sd_setImage(with: URL.init(string: strUrl), placeholderImage: nil, options: .continueInBackground, completed: nil)
                
                return cell
                
            }else{
                
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
                
                let imgViewBg = cell.contentView.viewWithTag(1001) as! UIImageView
                imgViewBg.layer.cornerRadius = 8
                
                let imgViewImg = cell.contentView.viewWithTag(1003) as! UIImageView
                let lblTitle = cell.contentView.viewWithTag(1002) as! UILabel
                
                let dictCategory = self.arrCategoryBottom.object(at: indexPath.item) as! NSDictionary
                
                print(dictCategory)
                
                lblTitle.text = dictCategory.value(forKey: "title") as! String
                
                let strUrl = dictCategory.value(forKey: "image") as! String
                
                imgViewImg.sd_setImage(with: URL.init(string: strUrl), placeholderImage: nil, options: .continueInBackground, completed: nil)
                
                return cell
            }
 //       }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
 //       if collectionView != collectionViewTop{
            
            if collectionView.accessibilityValue == "0"{
                
                let detailvc = self.storyboard?.instantiateViewController(withIdentifier: "DetailCategoryVC") as! DetailCategoryVC
                
                detailvc.dictDetailsCollection = arrCategory[indexPath.row] as! NSDictionary
                
                self.navigationController?.pushViewController(detailvc, animated: true)

            }else{
                
                let detailvc = self.storyboard?.instantiateViewController(withIdentifier: "DetailCategoryVC") as! DetailCategoryVC
                
                detailvc.dictDetailsCollection = arrCategoryBottom[indexPath.row] as! NSDictionary
                
                self.navigationController?.pushViewController(detailvc, animated: true)
            }
//        }else{
//
//            let sliderWebVC = self.storyboard?.instantiateViewController(withIdentifier: "SliderHomeWebViewVC") as! SliderHomeWebViewVC
//
//            sliderWebVC.dictUrl = self.arrSlider.object(at: indexPath.item) as! NSDictionary
//
//            self.navigationController?.pushViewController(sliderWebVC, animated: true)
//        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
//        if collectionView == collectionViewTop{
//
//            let size = CGSize.init(width: UIScreen.main.bounds.size.width, height: 213)
//
//            return size
//
//        }else{
        
            let size = CGSize.init(width: 70, height: 100)
            
            return size
 //       }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
//        if collectionView == collectionViewTop{
//
//            return UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
//
//        }else{
        
            return UIEdgeInsets.init(top: 5, left: 15, bottom: 5, right: 15)
  //      }

    }
    
    @objc func clickOnLeftBarBtn(btn:UIButton){
        
        let settingVC = self.storyboard?.instantiateViewController(withIdentifier: "SeetingViewController") as! SeetingViewController
        
        self.navigationController?.pushViewController(settingVC, animated: true)
    }
    
    @objc func clickOnRightBarBtn(btn:UIButton){
        
        let searchVC = self.storyboard?.instantiateViewController(withIdentifier: "SearchBarViewController") as! SearchBarViewController
        
        self.navigationController?.pushViewController(searchVC, animated: true)
    }

}
