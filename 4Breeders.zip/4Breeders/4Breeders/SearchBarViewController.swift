//
//  SearchBarViewController.swift
//  4Breeders
//
//  Created by Rp on 07/06/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class SearchBarViewController: UIViewController,responseDelegate,UISearchBarDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var arrSearch = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    func getSearchData(){
        
        let strParam = "lang=\(appDelegate.strLanguage)&search_title=\(searchBar.text as! String)"
        
        let strUrl = "http://4breeders.com/Api/Searchads"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getSearchData", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                self.arrSearch = Response.value(forKey: "data") as! NSArray
                print(self.arrSearch)
                self.collectionView.reloadData()
                
            }
            
            
        }else{
            
        }
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        self.getSearchData()
        
        searchBar.resignFirstResponder()
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrSearch.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        let view = cell.contentView.viewWithTag(1000) as! UIView
        view.layer.cornerRadius = 5
        view.layer.masksToBounds = true
        
        let imgView = cell.contentView.viewWithTag(1002) as! UIImageView
        
        let lblDescription = cell.contentView.viewWithTag(1003) as! UILabel
        
        let dictSearch = self.arrSearch.object(at: indexPath.row) as! NSDictionary
        
        let strurlImg = dictSearch.value(forKey: "image") as! String
        
        let imgPath = "http:sachinsam.com/4breeders/attachments/shop_images/\(strurlImg)"
        
        imgView.sd_setImage(with: URL.init(string: imgPath), placeholderImage: nil, options: .continueInBackground, completed: nil)
        
        lblDescription.text = dictSearch.value(forKey: "description") as? String
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let descriptionVc = self.storyboard?.instantiateViewController(withIdentifier: "DescriptionViewController") as! DescriptionViewController
        
        descriptionVc.dictAddDetails = self.arrSearch.object(at: indexPath.row) as! NSDictionary
        
     //   descriptionVc.isfromFavourite = true
        
        self.navigationController?.pushViewController(descriptionVc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let size = CGSize.init(width: (UIScreen.main.bounds.size.width-30)/2, height: 220)
        
        return size
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets.init(top: 10, left: 5, bottom: 10, right: 5)
    }

}
