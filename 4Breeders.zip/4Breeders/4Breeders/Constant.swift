//
//  Constant.swift
//  4Breeders
//
//  Created by Rp on 15/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import Foundation


let appDelegate = UIApplication.shared.delegate as! AppDelegate
