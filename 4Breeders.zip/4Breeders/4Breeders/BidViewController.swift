//
//  BidViewController.swift
//  4Breeders
//
//  Created by Rp on 26/04/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit
import MWPhotoBrowser


class BidViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIGestureRecognizerDelegate,responseDelegate,JOLImageSliderDelegate,UITextViewDelegate {

    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var viewImgSlider: UIView!
    @IBOutlet weak var viewBid: UIView!
    @IBOutlet weak var lblTopNumber: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblCost: UILabel!
    
    @IBOutlet weak var lblStaticStartingCost: UILabel!
    @IBOutlet weak var lblStaticRemainingTime: UILabel!
    
    @IBOutlet weak var lblTypeBid: UILabel!
    @IBOutlet weak var tblView: UITableView!
    
    @IBOutlet weak var viewHeightDescription: NSLayoutConstraint!
    @IBOutlet weak var viewMainHeight: NSLayoutConstraint!
    
    @IBOutlet weak var viewMain: UIView!
    var dictAllBidDetails = NSDictionary()
    
    var arrSingleComment = NSArray()
    
    var dictSingleBid = NSDictionary()
    
    var arrImageSlider = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
//        imgViewProfile.layer.borderWidth = 1.5
//        imgViewProfile.layer.borderColor = UIColor.init(red: 236/255, green: 103/255, blue: 90/255, alpha: 1).cgColor
        
   //     let strUrlImg = dictAllBidDetails.value(forKey: "image") as! String
 //       imgViewProfile.sd_setImage(with: URL.init(string: strUrlImg), placeholderImage: nil, options: .continueInBackground, completed: nil)
        
        if appDelegate.dictStaticWord.count > 0{
            
            lblStaticStartingCost.text = appDelegate.dictStaticWord.value(forKey: "Starting Cost") as! String
            lblStaticRemainingTime.text = appDelegate.dictStaticWord.value(forKey: "Remaining Time") as! String
            
        }
        lblTitle.text = dictAllBidDetails.value(forKey: "bid_name") as! String
        
        lblDescription.text = dictAllBidDetails.value(forKey: "description") as! String
        
        lblDescription.frame = CGRect.init(x: 0, y: 6.5, width: UIScreen.main.bounds.size.width-24, height: 21)
        lblDescription.numberOfLines = 0
        lblDescription.sizeToFit()
        
        viewHeightDescription.constant = lblDescription.frame.origin.y + lblDescription.frame.size.height + 5
        
        viewMainHeight.constant = lblDescription.frame.origin.y + lblDescription.frame.size.height + 85
        
        viewMain.frame = CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: lblDescription.frame.origin.y + lblDescription.frame.size.height + 365)
        
        
    //    lblTime.text = dictAllBidDetails.value(forKey: "Start_Time") as! String
        lblCost.text = dictAllBidDetails.value(forKey: "price") as! String
        lblTypeBid.text = dictAllBidDetails.value(forKey: "bid_type") as! String
        lblTopNumber.text = dictAllBidDetails.value(forKey: "visitor") as! String
        
        viewBid.layer.cornerRadius = viewBid.frame.size.height/2
        viewBid.layer.masksToBounds = true
        
//        tblView.estimatedRowHeight = 85
//        tblView.rowHeight = UITableView.automaticDimension
        
        
        
        print(dictAllBidDetails)
        
        
    }
    
    @objc func setReamainingTime()
    {
        let strDate = "\(dictSingleBid.value(forKey: "Day") as! String) \(dictSingleBid.value(forKey: "Start_Time") as! String):00"
        
        let currentDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy hh:mm:ss"
        let today = dateFormatter.string(from: currentDate)
        let todayDate = dateFormatter.date(from: today)
        
        let futureDate = dateFormatter.date(from: strDate)
        
        if futureDate != nil
        
        {
            let difference = Calendar.current.dateComponents([.hour, .minute, .second], from: todayDate!, to: futureDate!)
            let formattedString = String(format: "%02ld:%02ld:%02ld", difference.hour!, difference.minute!,difference.second!)
            
            if difference.hour! > 0 && difference.minute! > 0{
                
                self.lblTime.text = formattedString
            }
            else{
                
                self.lblTime.text = "00:00:00"
            }
        }
        else{
            
            lblTime.text = "00:00:00"
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationItem.title = "4BREEDERS"
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
        
        if appDelegate.strLanguage == "en"{
            
            var img = UIImage.init(named: "backIcon")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else if appDelegate.strLanguage == "ru"{
            
            var img = UIImage.init(named: "backIcon")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else{
            
            var img = UIImage.init(named: "backIcon")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
        }
        
        let rightBarBtn = UIBarButtonItem.init(image: UIImage.init(named: "search_icon"), style: .plain, target: self, action: #selector(clickOnRightBarBtn(btn:)))
        self.navigationItem.rightBarButtonItem = rightBarBtn
        
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(tapOnViewBid(Gesture:)))
        tapGesture.delegate = self
        viewBid.isUserInteractionEnabled = true
        viewBid.addGestureRecognizer(tapGesture)
        
        self.getSingleBid()

        self.getBidSingleComment()
        
        NotificationCenter.default.addObserver(self, selector: #selector(realodData), name: NSNotification.Name(rawValue: "UpdateComments"), object: nil)

    }
    
    @objc func realodData()
    {
        self.getBidSingleComment()
    }
    
    func postVisitorView(){
        
        let dict = self.arrSingleComment.object(at: 0) as! NSDictionary
        
        let strId = dict.value(forKey: "post_id") as! String
        
        let strParam = "id=\(strId)"
        
        let strUrl = "http://4breeders.com/Api/Visitors"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "postVisitorView", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func getSingleBid(){

        let strId = dictAllBidDetails.value(forKey: "for_id") as! String

        let strParam = "lang=\(appDelegate.strLanguage)&id=\(strId)"

        let strUrl = "http://4breeders.com/Api/Singlebid/getsinglebid"

        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "GetSingleBid", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func getBidSingleComment(){
        
        let strId = dictAllBidDetails.value(forKey: "for_id") as! String
        
        let strParam = "lang=\(appDelegate.strLanguage)&id=\(strId)"
        
        let strUrl = "http://4breeders.com/Api/Singlecomment/getAds"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getBidSingleComment", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if ServiceName == "getBidSingleComment"{
            
            if result == "1"{
                
                DispatchQueue.main.async {
                    
                    self.arrSingleComment = Response.value(forKey: "data") as! NSArray
                    print(self.arrSingleComment)
                    
                    self.postVisitorView()

                    self.tblView.reloadData()
                }
                
                
            }else{
                
            }
            
        }
        else if ServiceName == "GetSingleBid"
        {
            if result == "1"{
                
                DispatchQueue.main.async {
                    
                    self.dictSingleBid = Response.value(forKey: "data") as! NSDictionary
                    print(self.dictSingleBid)
                    
                    Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.setReamainingTime), userInfo: nil, repeats: true)

                    
                    let strImage = self.dictSingleBid.value(forKey: "image") as! String
                    
                    let slide = JOLImageSlide()
                    slide.image = strImage
                    self.arrImageSlider.add(slide)

                   // self.photos.add(MWPhoto.init(url: URL.init(string: strImage)))
                    
                    if !(self.dictSingleBid.value(forKey: "gallery") as! AnyObject).isKind(of: NSNull.self){
                        
                        let arrKey = self.dictSingleBid.value(forKey: "gallery") as! NSArray
                        
                        for index in 0..<arrKey.count
                        {
//                            let strImage = "http:sachinsam.com/4breeders/attachments/shop_images/\(arrKey.object(at: index))"
                            
                        let strImage = arrKey.object(at: index)
                            
                         //   self.photos.add(MWPhoto.init(url: URL.init(string: strImage)))
                            
                            //self.arrImageSlider.add(strImage)
                            
                            let slide = JOLImageSlide()
                            slide.image = strImage as! String
                            self.arrImageSlider.add(slide)
                        }
                        
                    }
                    
                    self.pageControl.numberOfPages = self.arrImageSlider.count
                    
                    let imageSlider = JOLImageSlider.init(frame: CGRect.init(x: 0, y: 0, width: (self.viewImgSlider.frame.size.width), height:self.viewImgSlider.frame.size.height), andSlides: self.arrImageSlider as! [Any])
                    imageSlider?.autoSlide = true
                    imageSlider?.delegate = self
                    self.viewImgSlider.addSubview(imageSlider!)
                }
                
                
            }else{
                
            }
            
        }else{
            
            if result == "1"{
                
                DispatchQueue.main.async {
                    
                }
                
            }else{
                
            }
        }

    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrSingleComment.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
 //       let mainView = cell.contentView.viewWithTag(1000) as! UIView
//        mainView.layer.cornerRadius = 7
//        mainView.layer.borderWidth = 1
//        mainView.layer.borderColor = UIColor.lightGray.cgColor
        
        let viewCount = cell.contentView.viewWithTag(1001) as! UIView
//        viewCount.layer.borderWidth = viewCount.frame.size.height/2
//        viewCount.layer.borderColor = UIColor.black.cgColor
        viewCount.layer.cornerRadius = viewCount.frame.size.height/2
        viewCount.layer.masksToBounds = true
        
        let lblCount = cell.contentView.viewWithTag(1002) as! UILabel
        let lblDes1 = cell.contentView.viewWithTag(1003) as! UILabel
        let lblDes2 = cell.contentView.viewWithTag(1004) as! UILabel
        
        let dictSingleComment = self.arrSingleComment.object(at: indexPath.row) as! NSDictionary
        
        lblDes1.text = dictSingleComment.value(forKey: "name") as! String
        lblDes2.text = dictSingleComment.value(forKey: "description") as! String
        
        lblCount.text = dictSingleComment.value(forKey: "price") as! String
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 85
        
  //      return UITableView.automaticDimension
    }
    
    
    @objc func clickOnLeftBarBtn(btn:UIButton){
        
//        let settingVC = self.storyboard?.instantiateViewController(withIdentifier: "SeetingViewController") as! SeetingViewController
//
//        self.navigationController?.pushViewController(settingVC, animated: true)
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func clickOnRightBarBtn(btn:UIButton){
        
        let searchVC = self.storyboard?.instantiateViewController(withIdentifier: "SearchBarViewController") as! SearchBarViewController
        
        self.navigationController?.pushViewController(searchVC, animated: true)
    }
    
    @objc func tapOnViewBid(Gesture:UITapGestureRecognizer){
        
        let BidOfferPopUp = self.storyboard?.instantiateViewController(withIdentifier: "MakeBidOfferPopUpVC") as! MakeBidOfferPopUpVC
        
        BidOfferPopUp.modalTransitionStyle = .crossDissolve
        
        if (UIDevice.current.systemVersion as! NSString).floatValue >= 8.0
        {
            BidOfferPopUp.modalPresentationStyle = .overCurrentContext
            BidOfferPopUp.definesPresentationContext = true
        }
        else{
            BidOfferPopUp.modalPresentationStyle = .currentContext
        }
        
        let strIdBid = dictAllBidDetails.value(forKey: "for_id") as! String
        BidOfferPopUp.strId = strIdBid
        
        BidOfferPopUp.dictBids = dictAllBidDetails
        
        self.present(BidOfferPopUp, animated: true, completion: nil)

    }

}
