//
//  MoreViewController.swift
//  4Breeders
//
//  Created by Rp on 26/04/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class MoreViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout,responseDelegate,UIGestureRecognizerDelegate {
    
    var arrDataFbInstaTwit = NSArray()
    
    var arrLableName = NSArray()
    
    @IBOutlet weak var imgViewYouTube: UIImageView!
    @IBOutlet weak var imgViewTwitter: UIImageView!
    @IBOutlet weak var imgViewFb: UIImageView!
    @IBOutlet weak var imgViewInstaGram: UIImageView!
    @IBOutlet weak var imgViewSnapChat: UIImageView!
    
    @IBOutlet weak var lblWeb: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let tapGestureFb = UITapGestureRecognizer.init(target: self, action: #selector(tapOnFaceBook))
        tapGestureFb.delegate = self
        imgViewFb.isUserInteractionEnabled = true
        imgViewFb.addGestureRecognizer(tapGestureFb)
        
        let tapGestureTwitter = UITapGestureRecognizer.init(target: self, action: #selector(tapOnTwitter))
        tapGestureTwitter.delegate = self
        imgViewTwitter.isUserInteractionEnabled = true
        imgViewTwitter.addGestureRecognizer(tapGestureTwitter)
        
        let tapGestureInsta = UITapGestureRecognizer.init(target: self, action: #selector(tapOnInstaGram))
        tapGestureInsta.delegate = self
        imgViewInstaGram.isUserInteractionEnabled = true
        imgViewInstaGram.addGestureRecognizer(tapGestureInsta)
        
        let tapGestureYouTube = UITapGestureRecognizer.init(target: self, action: #selector(tapOnYouTube(gesture:)))
        tapGestureYouTube.delegate = self
        imgViewYouTube.isUserInteractionEnabled = true
        imgViewYouTube.addGestureRecognizer(tapGestureYouTube)
        
        let tapGestureSnap = UITapGestureRecognizer.init(target: self, action: #selector(tapOnSnapChat(Gesture:)))
        tapGestureSnap.delegate = self
        imgViewSnapChat.isUserInteractionEnabled = true
        imgViewSnapChat.addGestureRecognizer(tapGestureSnap)
        
        let tapGestureWeb = UITapGestureRecognizer.init(target: self, action: #selector(tapOnLblWeb(gesture:)))
        tapGestureWeb.delegate = self
        lblWeb.isUserInteractionEnabled = true
        lblWeb.addGestureRecognizer(tapGestureWeb)
        
        self.getFbInstaTwitterData()
        
        NotificationCenter.default.addObserver(self, selector: #selector(languageChangedDone), name: NSNotification.Name(rawValue: "languageChanged"), object: nil)
    }
    
    @objc func languageChangedDone(){
        
        self.getFbInstaTwitterData()
    }

    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationItem.title = "4BREEDERS"
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
        
        if UIScreen.main.bounds.size.height > 667
        {
            let imgView = UIImageView()
            imgView.frame = CGRect.init(x: 0, y: -20, width: UIScreen.main.bounds.size.width, height: 64)
            imgView.image = UIImage.init(named: "header-bg-w-background")
            
            self.navigationController?.navigationBar.insertSubview(imgView, at: 1)
        }
        else{
            self.navigationController?.navigationBar.setBackgroundImage(UIImage.init(named: "header-bg-w-background"), for: .default)
            
        }
        
        if appDelegate.strLanguage == "en"{
            
            var img = UIImage.init(named: "usa_flag")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else if appDelegate.strLanguage == "ru"{
            
            var img = UIImage.init(named: "russia_flagSmall")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else{
            
            var img = UIImage.init(named: "kuwait_flagSmall")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
        }
        let rightBarBtn = UIBarButtonItem.init(image: UIImage.init(named: "search_icon"), style: .plain, target: self, action: #selector(clickOnRightBarBtn(btn:)))
        self.navigationItem.rightBarButtonItem = rightBarBtn
        
        self.navigationController?.navigationBar.isTranslucent = false
    }
    
    func getFbInstaTwitterData(){
        
        let strParam = "lang=\(appDelegate.strLanguage)"
        
        let strUrl = "http://4breeders.com/Api/Social"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getFbInstaTwitterData", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                self.arrDataFbInstaTwit = Response.value(forKey: "data") as! NSArray
                print(self.arrDataFbInstaTwit)
            }
            
            
        }else{
            
        }

    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 6
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
         if appDelegate.strLanguage == "en"
         {
            arrLableName = ["My ads","Favouirts","Setting","Our Policy","Customer Support","Contact Us"]
        }
        else if appDelegate.strLanguage == "ar"
         {
            arrLableName = ["اعلاناتي","المفضلة","اعدادات","شروط و الاحكام","خدمة العملاء","تواصل معنا"]
            
         }else{
            
            arrLableName = ["Мои объявления","любимый","настройка","Наша политика","Служба поддержки","Связаться с нами"]
        }
        
        let arrImg = [UIImage(named: "folderMore"),UIImage(named: "more_favouirts_icon"),UIImage(named: "more_setting_icon"),UIImage(named: "more_about_icon"),UIImage(named: "more_call_icon"),UIImage(named: "more_contact_icon")]
        
        let viewImg = cell.contentView.viewWithTag(1001) as! UIView
        viewImg.layer.cornerRadius = viewImg.frame.size.height/2
        viewImg.layer.masksToBounds = true
        
        let imgView = cell.contentView.viewWithTag(1002) as! UIImageView
        imgView.image = arrImg[indexPath.item]
        
        let lblName = cell.contentView.viewWithTag(1003) as! UILabel
        lblName.text = arrLableName[indexPath.item] as! String
        
        if indexPath.row == 4{
            
            viewImg.backgroundColor = UIColor.green
            
        }else{
            
            viewImg.backgroundColor = UIColor.init(red: 239/255, green: 103/255, blue: 90/255, alpha: 1)
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if indexPath.row == 0
        {
            
            let myAdsVc = self.storyboard?.instantiateViewController(withIdentifier: "MyAdsViewController") as! MyAdsViewController
            self.navigationItem.title = "   My Ads"
            self.navigationController?.pushViewController(myAdsVc, animated: true)
            
        }else if indexPath.row == 1{
            
            let myFavouriteVc = self.storyboard?.instantiateViewController(withIdentifier: "MyFavouritesViewController") as! MyFavouritesViewController
            self.navigationItem.title = "   My Favourites"
            self.navigationController?.pushViewController(myFavouriteVc, animated: true)
            
        }else if indexPath.row == 2{
            
            let myFavouriteVc = self.storyboard?.instantiateViewController(withIdentifier: "SeetingViewController") as! SeetingViewController
            self.navigationItem.title = "    Setting"
            self.navigationController?.pushViewController(myFavouriteVc, animated: true)
            
        }else if indexPath.row == 3{
            
            let aboutUsVc = self.storyboard?.instantiateViewController(withIdentifier: "AboutUsViewController") as! AboutUsViewController
            self.navigationItem.title = "   About Us"
            self.navigationController?.pushViewController(aboutUsVc, animated: true)
            
        }else if indexPath.row == 4{
            
            let supportVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomerSupportVC") as! CustomerSupportVC
            self.navigationItem.title = "   Customer Support"
            self.navigationController?.pushViewController(supportVC, animated: true)
            
        }else{
            
            let contactVC = self.storyboard?.instantiateViewController(withIdentifier: "ContactUsViewController") as! ContactUsViewController
            self.navigationItem.title = "   Contact Us"
            self.navigationController?.pushViewController(contactVC, animated: true)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
      //  let width = (UIScreen.main.bounds.size.width-90)/3
        
        let size = CGSize.init(width: 65, height: 120)
        
        return size
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets.init(top: 15, left: 15, bottom: 20, right: 15)
    }
    
    
    @objc func clickOnLeftBarBtn(btn:UIButton){
        
        let settingVC = self.storyboard?.instantiateViewController(withIdentifier: "SeetingViewController") as! SeetingViewController
        
        self.navigationController?.pushViewController(settingVC, animated: true)
    }
    
    @objc func clickOnRightBarBtn(btn:UIButton){
        
        let searchVC = self.storyboard?.instantiateViewController(withIdentifier: "SearchBarViewController") as! SearchBarViewController
        
        self.navigationController?.pushViewController(searchVC, animated: true)
    }
    
    @objc func tapOnInstaGram(){
        
        let dictData = self.arrDataFbInstaTwit.object(at: 0) as! NSDictionary
        
        print(dictData)
        
        let strUrl = dictData.value(forKey: "Instagram") as! String
        
        UIApplication.shared.open(URL.init(string: strUrl)!, options: [:], completionHandler: nil)
    }
    
    @objc func tapOnFaceBook(){
        
        let dictData = self.arrDataFbInstaTwit.object(at: 0) as! NSDictionary
        
        print(dictData)
        
        let strUrl = dictData.value(forKey: "Facebook") as! String
        
        UIApplication.shared.open(URL.init(string: strUrl)!, options: [:], completionHandler: nil)
    }
    
    @objc func tapOnTwitter(){
        
        let dictData = self.arrDataFbInstaTwit.object(at: 0) as! NSDictionary
        
        print(dictData)
        
        let strUrl = dictData.value(forKey: "Twitter") as! String
        
        UIApplication.shared.open(URL.init(string: strUrl)!, options: [:], completionHandler: nil)
    }
    
    @objc func tapOnSnapChat(Gesture:UITapGestureRecognizer){
        
        let dictData = self.arrDataFbInstaTwit.object(at: 0) as! NSDictionary
        
        print(dictData)
        
        let strUrl = dictData.value(forKey: "snapchat") as! String
        
        UIApplication.shared.open(URL.init(string: strUrl)!, options: [:], completionHandler: nil)
    }
    
    @objc func tapOnYouTube(gesture:UITapGestureRecognizer){
        
        let dictData = self.arrDataFbInstaTwit.object(at: 0) as! NSDictionary
        
        print(dictData)
        
        let strUrl = dictData.value(forKey: "youtube") as! String
        
        UIApplication.shared.open(URL.init(string: strUrl)!, options: [:], completionHandler: nil)
    }
    
    @objc func tapOnLblWeb(gesture:UITapGestureRecognizer){
        
        let strUrl = "https://www.4breeders.com"
        
        UIApplication.shared.open(URL.init(string: strUrl)!, options: [:], completionHandler: nil)
    }

}
