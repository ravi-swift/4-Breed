//
//  DirectoryViewController.swift
//  4Breeders
//
//  Created by Rp on 20/06/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class DirectoryViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,responseDelegate,UIGestureRecognizerDelegate {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var imgViewHeader: UIImageView!
    
    var arrDirectory = NSArray()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let strUrlImg = "http://4breeders.com/banner4.png"
        imgViewHeader.sd_setImage(with: URL.init(string: strUrlImg), placeholderImage: nil, options: .continueInBackground)
        
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(tapOnImgHeader(gesture:)))
        tapGesture.delegate = self
        imgViewHeader.isUserInteractionEnabled = true
        imgViewHeader.addGestureRecognizer(tapGesture)
        
        self.getDerictoryDetails()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationItem.title = "4BREEDERS"
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
        
        if UIScreen.main.bounds.size.height > 667
        {
            let imgView = UIImageView()
            imgView.frame = CGRect.init(x: 0, y: -20, width: UIScreen.main.bounds.size.width, height: 64)
            imgView.image = UIImage.init(named: "header-bg-w-background")
            
            self.navigationController?.navigationBar.insertSubview(imgView, at: 1)
        }
        else{
            self.navigationController?.navigationBar.setBackgroundImage(UIImage.init(named: "header-bg-w-background"), for: .default)
            
        }
        
        
        if appDelegate.strLanguage == "en"{
            
            var img = UIImage.init(named: "usa_flag")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else if appDelegate.strLanguage == "ru"{
            
            var img = UIImage.init(named: "russia_flagSmall")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else{
            
            var img = UIImage.init(named: "kuwait_flagSmall")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
        }
        
        let rightBarBtn = UIBarButtonItem.init(image: UIImage.init(named: "search_icon"), style: .plain, target: self, action: #selector(clickOnRightBarBtn(btn:)))
        self.navigationItem.rightBarButtonItem = rightBarBtn
        
        NotificationCenter.default.addObserver(self, selector: #selector(languageChangedDone), name: NSNotification.Name(rawValue: "languageChanged"), object: nil)
        
        self.navigationController?.navigationBar.isTranslucent = false
    }
    
    @objc func languageChangedDone(){
        
    }

    
    func getDerictoryDetails(){
        
        let strParam = "lang=\(appDelegate.strLanguage)"
        
        let strUrl = "http://4breeders.com/Api/Directorylist/getdirectory"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getDerictoryDetails", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                self.arrDirectory = Response.value(forKey: "data") as! NSArray
                print(self.arrDirectory)
                self.collectionView.reloadData()
            }
            
            
        }else{
            
        }
    }

    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrDirectory.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        let imgView = cell.contentView.viewWithTag(1001) as! UIImageView
        imgView.layer.cornerRadius = imgView.frame.size.height/2
        imgView.layer.masksToBounds = true
        
        let lblName = cell.contentView.viewWithTag(1002) as! UILabel
        let imgViewFlag = cell.contentView.viewWithTag(1003) as! UIImageView
        let lblDescriptin = cell.contentView.viewWithTag(1004) as! UILabel
        
        let dictDirectory = self.arrDirectory.object(at: indexPath.row) as! NSDictionary
        
        let strUrl = dictDirectory.value(forKey: "image") as! String
        imgView.sd_setImage(with: URL.init(string: strUrl), placeholderImage: nil, options: .continueInBackground, completed: nil)
        
        lblName.text = dictDirectory.value(forKey: "Name") as! String
        
        let strUrlFlag = dictDirectory.value(forKey: "flag") as! String
        imgViewFlag.sd_setImage(with: URL.init(string: strUrlFlag), placeholderImage: nil, options: .continueInBackground, completed: nil)
        
        lblDescriptin.text = dictDirectory.value(forKey: "tag") as! String
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let size = CGSize.init(width: 100, height: 145)
        
        return size
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let singleDirectoryVC = self.storyboard?.instantiateViewController(withIdentifier: "SingleDirectoryViewController") as! SingleDirectoryViewController
        
        singleDirectoryVC.dictDirectoryDetails = self.arrDirectory.object(at: indexPath.row) as! NSDictionary
        
        self.navigationController?.pushViewController(singleDirectoryVC, animated: true)
    }
    
    
    
    @objc func clickOnLeftBarBtn(btn:UIButton){
        
        let settingVC = self.storyboard?.instantiateViewController(withIdentifier: "SeetingViewController") as! SeetingViewController
        
        self.navigationController?.pushViewController(settingVC, animated: true)
    }
    
    @objc func clickOnRightBarBtn(btn:UIButton){
        
        let searchVC = self.storyboard?.instantiateViewController(withIdentifier: "SearchBarViewController") as! SearchBarViewController
        
        self.navigationController?.pushViewController(searchVC, animated: true)
    }
    
    @objc func tapOnImgHeader(gesture:UITapGestureRecognizer){
        
        let strUrl = "http://4breeders.com/banner4.php"
        
        UIApplication.shared.open(URL.init(string: strUrl)!, options: [:], completionHandler: nil)
    }

}
