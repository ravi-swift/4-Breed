//
//  CustomerSupportVC.swift
//  4Breeders
//
//  Created by Rp on 30/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class CustomerSupportVC: UIViewController,responseDelegate {

    @IBOutlet weak var txvDescription: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.getCustomerSupport()
    }
    
    func getCustomerSupport(){
        
        let strParam = "lang=\(appDelegate.strLanguage)"
        
        let strUrl = "http://4breeders.com/Api/Privacy/Livechat"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getAboutData", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
        
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                let arrSupport = Response.value(forKey: "data") as! NSArray
                
                let dictSuppot = arrSupport.object(at: 0) as! NSDictionary
                
                self.txvDescription.attributedText = (dictSuppot.value(forKey: "description") as! String).html2AttributedString
                
                self.txvDescription.textAlignment = .right
            }
            
            
        }else{
            
        }
    }

}
extension Data {
    var html2AttributedString: NSAttributedString? {
        do {
            return try NSAttributedString(data: self, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding: String.Encoding.utf8.rawValue], documentAttributes: nil)
        } catch {
            print("error:", error)
            return  nil
        }
    }
    var html2String: String {
        return html2AttributedString?.string ?? ""
    }
}

extension String {
    var html2AttributedString: NSAttributedString? {
        return Data(utf8).html2AttributedString
    }
    var html2String: String {
        return html2AttributedString?.string ?? ""
    }
}
