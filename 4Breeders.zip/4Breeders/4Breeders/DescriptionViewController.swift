//
//  DescriptionViewController.swift
//  4Breeders
//
//  Created by Rp on 07/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit
import MessageUI
import MWPhotoBrowser
import AVKit


class DescriptionViewController: UIViewController,responseDelegate,UIGestureRecognizerDelegate,MFMessageComposeViewControllerDelegate,UINavigationControllerDelegate,JOLImageSliderDelegate {
    
  //  @IBOutlet weak var imgViewTop: UIImageView!
    @IBOutlet weak var txViewDescription: UITextView!
  //  @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var viewImgSlider: UIView!
    
    @IBOutlet var viewCall : UIView!
    @IBOutlet var viewMessage : UIView!
    @IBOutlet var viewShare : UIView!
    @IBOutlet var viewFavourite : UIView!
    @IBOutlet weak var viewViewers: UIView!
    @IBOutlet weak var lblViewrs: UILabel!
    @IBOutlet weak var lblPostDate: UILabel!
    @IBOutlet weak var pageControl: UIPageControl!
    
    @IBOutlet weak var imgViewFav: UIImageView!
    
    var statusFav : String = ""
    var strVideo : String = ""
    
    var dictAddDetails = NSDictionary()
    var dictAddDescription = NSMutableDictionary()
    var arrImageSlider = NSMutableArray()
    
    var isfromFavourite : Bool = false
 //   var isFromSearchBar : Bool = false
    
    var photos = NSMutableArray()
    
  //  var arrDetailsAds = NSArray()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.viewRedious(view: viewCall)
        self.viewRedious(view: viewShare)
        self.viewRedious(view: viewMessage)
        self.viewRedious(view: viewFavourite)
        
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(tapOnViewFavourite(gesture:)))
        tapGesture.delegate = self
        viewFavourite.isUserInteractionEnabled = true
        viewFavourite.addGestureRecognizer(tapGesture)
        
        let tapGestureCall = UITapGestureRecognizer.init(target: self, action: #selector(tapOnCall(gesture:)))
        tapGestureCall.delegate = self
        viewCall.isUserInteractionEnabled = true
        viewCall.addGestureRecognizer(tapGestureCall)
        
        let gestureViewers = UITapGestureRecognizer.init(target: self, action: #selector(tapOnViewers(gesture:)))
        gestureViewers.delegate = self
        viewViewers.isUserInteractionEnabled = true
        viewViewers.addGestureRecognizer(gestureViewers)
        
        let tapGestureMessage = UITapGestureRecognizer.init(target: self, action: #selector(tapOnMessage(gesture:)))
        tapGestureMessage.delegate = self
        viewMessage.isUserInteractionEnabled = true
        viewMessage.addGestureRecognizer(tapGestureMessage)
        
        let tapGestureShare = UITapGestureRecognizer.init(target: self, action: #selector(tapOnShare(gesture:)))
        tapGestureShare.delegate = self
        viewShare.isUserInteractionEnabled = true
        viewShare.addGestureRecognizer(tapGestureShare)
        
    }

    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationItem.title = "4BREEDERS"
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
        
        if appDelegate.strLanguage == "en"{
            
            var img = UIImage.init(named: "backIcon")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -15, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else if appDelegate.strLanguage == "ru"{
            
            var img = UIImage.init(named: "backIcon")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -15, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else{
            
            var img = UIImage.init(named: "backIcon")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -15, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
        }
        
        let rightBarBtn = UIBarButtonItem.init(image: UIImage.init(named: "search_icon"), style: .plain, target: self, action: #selector(clickOnRightBarBtn(btn:)))
        self.navigationItem.rightBarButtonItem = rightBarBtn

        self.getAdsDetails()

    }
    
    /*
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if dictAddDescription.count > 0{
            
            return self.arrImageSlider.count
        }
        
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        let imgView = cell.contentView.viewWithTag(1001) as! UIImageView
        
        let strUrlImg = self.arrImageSlider.object(at: indexPath.item) as! String
        
        imgView.sd_setImage(with: URL.init(string: strUrlImg), placeholderImage: UIImage.init(named: "default-image"), options: .continueInBackground, completed: nil)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = UIScreen.main.bounds.size.width-48
        
        let size = CGSize.init(width: width, height: 206)
        
        return size
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let controller = MWPhotoBrowser.init(photos: self.photos as! [Any])
        controller?.displayActionButton = false
        self.navigationController?.pushViewController(controller!, animated: true)
    }
 
 */
    
    func imagePager(_ imagePager: JOLImageSlider!, didSelectImageAt index: UInt) {
        
        let arrSlide = imagePager.slideArray as! NSArray
        let slide = arrSlide.object(at: Int(index)) as! JOLImageSlide
        if slide.accessibilityValue == "video"
        {
            let videoURL = URL(string: self.strVideo)
            let player = AVPlayer(url: videoURL!)
            let playerViewController = AVPlayerViewController()
            playerViewController.player = player
            self.present(playerViewController, animated: true) {
                playerViewController.player!.play()
            }
        }
        else{
            let controller = MWPhotoBrowser.init(photos: self.photos as! [Any])
            controller?.displayActionButton = false
            self.navigationController?.pushViewController(controller!, animated: true)
        }
        
       
    }
    
    @objc func tapOnViewFavourite(gesture:UITapGestureRecognizer){
        
        let statusFavourite = dictAddDescription.value(forKey: "fav") as! String
        
        if statusFavourite == "1"{
            
            statusFav = "0"
            
            self.imgViewFav.image = UIImage.init(named: "fav-icon")
            
        }else{
            
            statusFav = "1"
            
            self.imgViewFav.image = UIImage.init(named: "added_Fav_icon")
        }
        
        self.dictAddDescription.setValue(statusFav, forKey: "fav")
        self.postFavourites()

    }
    
    func getAdsDetails(){
        
        print(dictAddDetails)
        var strId : String = ""
        if isfromFavourite{
            
            strId = dictAddDetails.value(forKey: "id") as! String
        }
        else{
            
            strId = dictAddDetails.value(forKey: "for_id") as! String
        }
        
        let strParam = "lang=\(appDelegate.strLanguage)&id=\(strId)"
        
        let strUrl = "http://4breeders.com/Api/Singleads/getsingleads"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getAdsDetails", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func postFavourites(){
        
        let strDeviceId = appDelegate.mobileId
        let strId = self.dictAddDescription.value(forKey: "id") as! String
        
        let strParam = "mob_id=\(strDeviceId)&id=\(strId)&Fav=\(statusFav)"
        
        let strUrl = "http://4breeders.com/Api/Favourite/Addfavourite"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "postFavourites", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func postViewrs(){
        
        let strId = self.dictAddDescription.value(forKey: "id") as! String
        
        let visitor = ""
        
        let strParam = "id=\(strId)&add_visitor=\(visitor)"
        
        let strUrl = "http://4breeders.com/Api/Addvisitors"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "GetViewrsData", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                if ServiceName == "getAdsDetails"{
                    
                    for subview in self.viewImgSlider.subviews
                    {
                        subview.removeFromSuperview()
                    }
                    
                    self.dictAddDescription = (Response.value(forKey: "data") as! NSDictionary).mutableCopy() as! NSMutableDictionary
                    
                    print(self.dictAddDescription)
                    
                    self.lblViewrs.text = self.dictAddDescription.value(forKey: "add_visitor") as! String
                    
                    self.lblPostDate.text = self.dictAddDescription.value(forKey: "postdate") as! String
                    
     //               let strUrlImg = self.dictAddDescription.value(forKey: "image") as! String
                    
    //                self.imgViewTop.sd_setImage(with: URL.init(string: strUrlImg), placeholderImage: nil, options: .continueInBackground, completed: nil)
                                        
                    self.txViewDescription.text = self.dictAddDescription.value(forKey: "description") as! String
                    
                    let favStatus = self.dictAddDescription.value(forKey: "fav") as! String
                    
                    self.photos.removeAllObjects()
                    self.arrImageSlider.removeAllObjects()
                    
                    if favStatus == "1"{
                        
                            self.imgViewFav.image = UIImage.init(named: "added_Fav_icon")
                        
                    }else{
                        
                        self.imgViewFav.image = UIImage.init(named: "fav-icon")
                    }
                    
                    let strImage = self.dictAddDescription.value(forKey: "image") as! String
                 
                    let slide = JOLImageSlide()
                    slide.image = strImage
                    self.arrImageSlider.add(slide)

                    
                    self.photos.add(MWPhoto.init(url: URL.init(string: strImage)))
                    
                     if !(self.dictAddDescription.value(forKey: "key") as! AnyObject).isKind(of: NSNumber.self){
                    
                    if !(self.dictAddDescription.value(forKey: "key") as! AnyObject).isKind(of: NSNull.self){
                    
                    let arrKey = self.dictAddDescription.value(forKey: "key") as! NSArray
                                            
                        for index in 0..<arrKey.count
                        {
                            let strImage = "\(arrKey.object(at: index))"
                           
                            self.photos.add(MWPhoto.init(url: URL.init(string: strImage)))

                            //self.arrImageSlider.add(strImage)
                            
                            let slide = JOLImageSlide()
                            slide.image = strImage
                            self.arrImageSlider.add(slide)
                        }
                    
                       
                    }
                    }
                    
                    if self.dictAddDescription.object(forKey: "thumbnail") != nil{
                        
                    
                    
                    if self.dictAddDescription.value(forKey: "thumbnail") as! String != ""
                    {
                        let slide = JOLImageSlide()
                        slide.image = self.dictAddDescription.value(forKey: "thumbnail") as! String
                        slide.accessibilityValue = "video"
                        self.arrImageSlider.add(slide)
                        
                        self.strVideo = self.dictAddDescription.value(forKey: "video") as! String
                    }
                        
                    }
                    
                    let imageSlider = JOLImageSlider.init(frame: CGRect.init(x: 0, y: 0, width: (self.viewImgSlider.frame.size.width), height:self.viewImgSlider.frame.size.height), andSlides: self.arrImageSlider as! [Any])
                    imageSlider?.autoSlide = true
                    imageSlider?.delegate = self
                    self.viewImgSlider.addSubview(imageSlider!)

                   
                    self.pageControl.numberOfPages = self.arrImageSlider.count
                    self.postViewrs()

//                    self.collectionView.reloadData()
                    
                }else if ServiceName == "postFavourites"{
                    
                    if self.statusFav == "1"{
                        
                        var controller = UIAlertController()
                        
                        if appDelegate.strLanguage == "en"
                        {
                            controller = UIAlertController.init(title: "Message", message: "Add to Favourites", preferredStyle: .alert)
                            
                        }else if appDelegate.strLanguage == "ar"
                        {
                         controller = UIAlertController.init(title: "Message", message: "تمت الاضافة في المفضلة", preferredStyle: .alert)
                            
                        }else{
                            
                            controller = UIAlertController.init(title: "Message", message: "Добавить в избранное", preferredStyle: .alert)
                        }
                        
                        let actionOk = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
                            
                            self.dismiss(animated: true, completion: nil)
                            
                        })
                        
                        controller.addAction(actionOk)
                        
                        self.present(controller, animated: true, completion: nil)
                        
        //                self.imgViewFav.image = UIImage.init(named: "added_Fav_icon")
                        
                    }else{
                        
                        var controller = UIAlertController()
                        
                        if appDelegate.strLanguage == "en"
                        {
                         controller = UIAlertController.init(title: "Message", message: "Remove from Favourites", preferredStyle: .alert)
                            
                        }else if appDelegate.strLanguage == "ar"
                        {
                           controller = UIAlertController.init(title: "Message", message: "تمت الحذف من المفضلة", preferredStyle: .alert)
                            
                        }else{
                          
                            controller = UIAlertController.init(title: "Message", message: "удалить из избранного", preferredStyle: .alert)
                        }
                        
                        let actionOk = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
                            
                            self.dismiss(animated: true, completion: nil)
                            
                        })
                        
                        controller.addAction(actionOk)
                        
                        self.present(controller, animated: true, completion: nil)
                        
      //                  self.imgViewFav.image = UIImage.init(named: "Fav_icon")
                    }
                }
                
                else if ServiceName == "GetViewrsData"
                {
                    
                }
            }
            
            
        }else{
            
        }
    }
    
    func viewRedious(view:UIView){
        
        view.layer.cornerRadius = view.frame.size.height/2
        view.layer.masksToBounds = true
    }
    
    @objc func clickOnLeftBarBtn(btn:UIButton){
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func clickOnRightBarBtn(btn:UIButton){
        
        let searchVC = self.storyboard?.instantiateViewController(withIdentifier: "SearchBarViewController") as! SearchBarViewController
        
        self.navigationController?.pushViewController(searchVC, animated: true)
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        
        switch result {
        case .sent:
            break
            
        case .cancelled:
            
            controller.dismiss(animated: true, completion: nil)
            break
            
        case .failed:
            break
            
        }
    }
    
    
    @objc func tapOnCall(gesture:UITapGestureRecognizer){
        
        let mobileNumber = "tel://\(self.dictAddDescription.value(forKey: "phone") as! String)"
        
        if let url = URL(string: mobileNumber),UIApplication.shared.canOpenURL(url){
            
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }

    }
    
    @objc func tapOnMessage(gesture:UITapGestureRecognizer){
        
        if MFMessageComposeViewController.canSendText(){
            
            let messanger = MFMessageComposeViewController.init()
            
            let mobileNumber = self.dictAddDescription.value(forKey: "phone") as! String
            
            messanger.body = self.dictAddDescription.value(forKey: "description") as! String
            messanger.subject = ""
            messanger.recipients = [mobileNumber]
            messanger.messageComposeDelegate = self
            self.present(messanger, animated: true, completion: nil)
            
        }
    }
    

    @objc func tapOnViewers(gesture:UITapGestureRecognizer){
        
        
    }
    
    @objc func tapOnShare(gesture:UITapGestureRecognizer){
        
        let activityController = UIActivityViewController.init(activityItems: [dictAddDescription.value(forKey: "description")as! String], applicationActivities: nil)

        self.present(activityController, animated: true, completion: nil)
    }
    
    func generateThumbnail(path: URL) -> UIImage? {
        do {
            let asset = AVURLAsset(url: path, options: nil)
            let imgGenerator = AVAssetImageGenerator(asset: asset)
            imgGenerator.appliesPreferredTrackTransform = true
            let cgImage = try imgGenerator.copyCGImage(at: CMTimeMake(value: 0, timescale: 1), actualTime: nil)
            let thumbnail = UIImage(cgImage: cgImage)
            return thumbnail
        } catch let error {
            print("*** Error generating thumbnail: \(error.localizedDescription)")
            return nil
        }
    }
    
}
