//
//  DetailCategoryVC.swift
//  4Breeders
//
//  Created by Rp on 26/04/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//



import UIKit

class DetailCategoryVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, responseDelegate {
    
    @IBOutlet weak var collectionViewTop: UICollectionView!
    @IBOutlet weak var collectionViewVertical: UICollectionView!
    
    var arrSubCategory = NSMutableArray()
    var arrAllAds = NSArray()
    var arrAds = NSMutableArray()
    
    var arrSpecialAds = NSArray()
    var dictDetailsCollection = NSDictionary()
    
    var selectedIndex : Int = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        print(dictDetailsCollection)
        
        //      self.getSpecialAds()
        self.getSubCategory()
        self.getAllAds()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationItem.title = "4BREEDERS"
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
        
        if appDelegate.strLanguage == "en"{
            
            var img = UIImage.init(named: "backIcon")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -15, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else if appDelegate.strLanguage == "ru"{
            
            var img = UIImage.init(named: "backIcon")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -15, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else{
            
            var img = UIImage.init(named: "backIcon")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -15, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
        }
        
        let rightBarBtn = UIBarButtonItem.init(image: UIImage.init(named: "search_icon"), style: .plain, target: self, action: #selector(clickOnRightBarBtn(btn:)))
        self.navigationItem.rightBarButtonItem = rightBarBtn
    }
    
    func getSubCategory(){
        
        let strId = dictDetailsCollection.value(forKey: "id") as! String
        
        let strParam = "lang=\(appDelegate.strLanguage)&shop_categorie=\(strId)"
        
        let strUrl = "http://4breeders.com/Api/Categeorysublist/getcategeory"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getSubCategory", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func getAllAds(){
        
        let strId = dictDetailsCollection.value(forKey: "id") as! String
        
        let strCountryCode  = appDelegate.strCountryCode.replacingOccurrences(of: "+", with: "%2B")
        
        let strParam = "lang=\(appDelegate.strLanguage)&shop_categorie=\(strId)&country=\(strCountryCode as! String)"
        
        //     let strParam = "lang=\(appDelegate.strLanguage)&shop_categorie=\(strId)"
        
        let strUrl = "http://4breeders.com/Api/CategeoryAds/Ads"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getAllAds", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    //    func getSpecialAds(){
    //
    //        let strId = dictDetailsCollection.value(forKey: "id") as! String
    //
    //        let strParam = "lang=\(appDelegate.strLanguage)&shop_categorie=\(strId)&country=\(appDelegate.strCountryCode)"
    //
    //        //     let strParam = "lang=\(appDelegate.strLanguage)&shop_categorie=\(strId)"
    //
    //        let strUrl = "http://4breeders.com/Api/Specialads/getspecialAds"
    //
    //        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getSpecialAds", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    //    }
    
    
    func getSubCategoryIndivisual(strIdSelected:String){
        
        // let dict = self.arrSubCategory.object(at: 0) as! NSDictionary
        
        let strCountryCode  = appDelegate.strCountryCode.replacingOccurrences(of: "+", with: "%2B")
        
        let strParam = "lang=\(appDelegate.strLanguage)&subcat_id=\(strIdSelected)&country=\(strCountryCode as! String)"
        
        let strUrl = "http://4breeders.com/Api/SubcategeoryAds/Subcategeoryads"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getSubCategoryIndivisual", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        if ServiceName == "getSubCategory"{
            
            let result = "\(Response.value(forKey: "status") as! Int)"
            
            if result == "1"{
                
                DispatchQueue.main.async {
                    
                    self.arrSubCategory.removeAllObjects()
                    
                    if appDelegate.strLanguage == "en"
                    {
                        self.arrSubCategory.add("All")
                        
                    }else if appDelegate.strLanguage == "ar"
                    {
                        self.arrSubCategory.add("الجميع")
                        
                    }else{
                        
                        self.arrSubCategory.add("Все")
                    }
                    
                    self.arrSubCategory.addObjects(from: Response.value(forKey: "data") as! [Any])
                    print(self.arrSubCategory)
                    self.collectionViewTop.reloadData()
                }
                
                
            }else{
                
            }
            
        }else if ServiceName == "getAllAds"{
            
            print(Response)
            
            let result = "\(Response.value(forKey: "status") as! Int)"
            
            if result == "1"{
                
                DispatchQueue.main.async {
                    
                    self.arrAds.removeAllObjects()
                    
                    self.arrAllAds = Response.value(forKey: "data") as! NSArray
                    
                    let filterdSpecial = NSPredicate.init(format: "special=%@","S")
                    let filteredSpecialArray = self.arrAllAds.filtered(using: filterdSpecial)
                    
                    let filterd = NSPredicate.init(format: "special != %@","S")
                    let filteredArray = self.arrAllAds.filtered(using: filterd)
                    
                    self.arrAds.addObjects(from: filteredSpecialArray)
                    self.arrAds.addObjects(from: filteredArray)
                    
                    self.collectionViewVertical.reloadData()
                }
                
                
            }else{
                
            }
            
        }
            //        else if ServiceName == "getSpecialAds"{
            //
            //            print(Response)
            //
            //            let result = "\(Response.value(forKey: "status") as! Int)"
            //
            //            if result == "1"{
            //
            //                DispatchQueue.main.async {
            //
            //                    self.arrSpecialAds = Response.value(forKey: "data") as! NSArray
            //                    print(self.arrSpecialAds)
            //                }
            //
            //            }else{
            //
            //            }
            //
            //        }
        else{
            
            let result = "\(Response.value(forKey: "status") as! Int)"
            
            if result == "1"{
                
                DispatchQueue.main.async {
                    
                    self.arrAds.removeAllObjects()

                    self.arrAllAds = Response.value(forKey: "data") as! NSArray
                    
                    let filterdSpecial = NSPredicate.init(format: "special=%@","S")
                    let filteredSpecialArray = self.arrAllAds.filtered(using: filterdSpecial)
                    
                    let filterd = NSPredicate.init(format: "special != %@","S")
                    let filteredArray = self.arrAllAds.filtered(using: filterd)
                    
                    self.arrAds.addObjects(from: filteredSpecialArray)
                    self.arrAds.addObjects(from: filteredArray)
                    
                    self.collectionViewVertical.reloadData()
                }
                
                
            }else{
                
                DispatchQueue.main.async {
                    
                    self.arrAds = NSMutableArray()
                    self.arrAllAds = NSArray()
                    self.collectionViewVertical.reloadData()
                }
            }
            
            print(Response)
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView == collectionViewTop {
            
            return arrSubCategory.count
            
        }else{
            
            return self.arrAds.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == collectionViewTop{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
            
            //let view = cell.contentView.viewWithTag(1000) as! UIView
            
            let lblCategoryName = cell.contentView.viewWithTag(1001) as! UILabel
            
            
            if indexPath.item > 0{
                let dictSubCategory = self.arrSubCategory.object(at: indexPath.item) as! NSDictionary
                lblCategoryName.text = dictSubCategory.value(forKey: "title") as? String
                lblCategoryName.frame = CGRect.init(x: 10, y: 4, width: 80, height: 22)
                //                lblCategoryName.layer.borderWidth = 1
                //                lblCategoryName.layer.borderColor = UIColor.black.cgColor
                lblCategoryName.sizeToFit()
            }
            else{
                
                if appDelegate.strLanguage == "en"
                {
                    lblCategoryName.text = "All"
                }
                else if appDelegate.strLanguage == "ar"
                {
                    lblCategoryName.text = "الجميع"
                    
                }else
                {
                    lblCategoryName.text = "Все"
                    
                }
            }
            
            if selectedIndex == indexPath.item{
                
                view.backgroundColor = UIColor.init(red: 169/255, green: 40/255, blue: 23/255, alpha: 1)
                
            }else{
                
                view.backgroundColor = UIColor.init(red: 235/255, green: 103/255, blue: 86/255, alpha: 1)
            }
            
            cell.layer.cornerRadius = 5
            cell.layer.masksToBounds = true
            
            return cell
            
        }else{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
            
            let view = cell.contentView.viewWithTag(1000) as! UIView
            view.layer.cornerRadius = 5
            view.layer.masksToBounds = true
            
            let imgViewSpecial = cell.contentView.viewWithTag(1001) as! UIImageView
            imgViewSpecial.isHidden = true
            
            let imgViewSpecialAds = cell.contentView.viewWithTag(1077) as! UIImageView
            
            
            let imgView = cell.contentView.viewWithTag(1002) as! UIImageView
            imgView.layer.cornerRadius = 5
            imgView.layer.masksToBounds = true
            imgView.layer.borderWidth = 1.5
            //  imgView.layer.borderColor = UIColor.init(red: 236/255, green: 103/255, blue: 90/255, alpha: 1).cgColor
            imgView.layer.borderColor = UIColor.black.cgColor
            
            let lblDescription = cell.contentView.viewWithTag(1003) as! UILabel
            
            let dictAllAds = self.arrAds.object(at: indexPath.row) as? NSDictionary
            
            if (dictAllAds?.value(forKey: "special") as! AnyObject).isKind(of: NSNull.self){
                imgViewSpecialAds.isHidden = true
            }
            else{
                imgViewSpecialAds.isHidden = false
            }
            
            
            let strUrlImg = dictAllAds?.value(forKey: "image") as! String
            imgView.sd_setImage(with: URL.init(string: strUrlImg), placeholderImage: UIImage.init(named: "default-image"), options: .continueInBackground, completed: nil)
            
            lblDescription.text = dictAllAds?.value(forKey: "description") as? String
            
            return cell
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if collectionView == collectionViewVertical{
            
            let descriptionVc = self.storyboard?.instantiateViewController(withIdentifier: "DescriptionViewController") as! DescriptionViewController
            
            descriptionVc.dictAddDetails = self.arrAds.object(at: indexPath.row) as! NSDictionary
            
            self.navigationController?.pushViewController(descriptionVc, animated: true)
            
        }else{
            
            
            if selectedIndex == indexPath.item
            {
                self.selectedIndex = -1
                self.collectionViewTop.reloadData()
                self.getAllAds()
                
            }
            else{
                
                if indexPath.item > 0 {
                    let dict = self.arrSubCategory.object(at: indexPath.row) as! NSDictionary
                    let strIdSelected = dict.value(forKey: "id") as! String
                    selectedIndex = indexPath.item
                    //             self.getSpecialAds()
                    self.getSubCategoryIndivisual(strIdSelected: strIdSelected)
                    collectionViewTop.reloadData()
                }
                else{
                    self.selectedIndex = -1
                    self.collectionViewTop.reloadData()
                    
                    self.getAllAds()
                    
                }
            }
            
            
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if collectionView == collectionViewTop{
            
            //         let size = CGSize.init(width: 70, height: 30)
            if arrSubCategory.count > 0{
                let label = UILabel(frame: CGRect.zero)
                if indexPath.item > 0{
                    let dict = arrSubCategory[indexPath.item] as! NSDictionary
                    if dict.value(forKey: "title") as? String != ""{
                        label.frame = CGRect.init(x: 10, y: 0, width: 80, height: 22)
                        label.text = dict.value(forKey: "title") as? String
                        label.frame = CGRect.init(x: 10, y: 0, width: 80, height: 22)
                        
                        label.sizeToFit()
                        return CGSize(width: label.frame.width + 20, height: 30)
                    }
                    else{
                        return CGSize(width: 0, height: 0)
                        
                    }
                }
                return CGSize(width: 80, height: 30)
                
            }
            return CGSize(width: 80, height: 30)
            
        }else{
            
            let size = CGSize.init(width: (UIScreen.main.bounds.size.width-30)/2, height: 220)
            
            return size
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        if collectionView == collectionViewTop{
            
            return UIEdgeInsets.init(top: 0, left: 10, bottom: 0, right: 10)
            
        }else{
            
            return UIEdgeInsets.init(top: 10, left: 5, bottom: 15, right: 5)
        }
    }
    
    @objc func clickOnLeftBarBtn(btn:UIButton){
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func clickOnRightBarBtn(btn:UIButton){
        
        let searchVC = self.storyboard?.instantiateViewController(withIdentifier: "SearchBarViewController") as! SearchBarViewController
        
        self.navigationController?.pushViewController(searchVC, animated: true)
    }
    
}


