//
//  SingleDirectoryViewController.swift
//  4Breeders
//
//  Created by Rp on 20/06/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit
import AVKit
import MessageUI
import MWPhotoBrowser

class SingleDirectoryViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,responseDelegate,UIGestureRecognizerDelegate,UINavigationControllerDelegate,MFMailComposeViewControllerDelegate {


    @IBOutlet weak var lblTag: UILabel!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var imgViewMain: UIImageView!
    @IBOutlet weak var viewMail: UIView!
    @IBOutlet weak var viewWorldWipe: UIView!
    @IBOutlet weak var viewCall: UIView!
    @IBOutlet weak var txtDescription: UITextView!
    
    var dictDirectoryDetails = NSDictionary()
    var dictSingleDirectory = NSDictionary()
    
    var arrPhotos = NSMutableArray()
    var arrImageAndVideo = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        imgViewMain.layer.borderWidth = 1.5
        imgViewMain.layer.borderColor = UIColor.init(red: 224/255, green: 94/255, blue: 89/255, alpha: 1).cgColor
        
        viewRedious(view: viewMail)
        
        let gestureCall = UITapGestureRecognizer.init(target: self, action: #selector(tapOnCall(gesture:)))
        gestureCall.delegate = self
        viewCall.isUserInteractionEnabled = true
        viewCall.addGestureRecognizer(gestureCall)

        let gestureMail = UITapGestureRecognizer.init(target: self, action: #selector(tapOnMail(gesture:)))
        gestureMail.delegate = self
        viewMail.isUserInteractionEnabled = true
        viewMail.addGestureRecognizer(gestureMail)
        
        let gestureWWW = UITapGestureRecognizer.init(target: self, action: #selector(tapOnWhatsapp(gesture:)))
        gestureWWW.delegate = self
        viewWorldWipe.isUserInteractionEnabled = true
        viewWorldWipe.addGestureRecognizer(gestureWWW)
        
        self.getSingleDirectory()
    }
    
    func viewRedious(view:UIView){
        
        view.layer.cornerRadius = view.frame.size.height/2
        view.layer.masksToBounds = true
    }
    
    func getSingleDirectory(){
        
        let strId = dictDirectoryDetails.value(forKey: "id") as! String
        
        let strParam = "lang=\(appDelegate.strLanguage)&id=\(strId)"
        
        let strUrl = "http://4breeders.com/Api/Singledirectory/getsingledirectory"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getSingleDirectory", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                self.dictSingleDirectory = Response.value(forKey: "data") as! NSDictionary
                
                print(self.dictSingleDirectory)
                
                let strUrl = self.dictSingleDirectory.value(forKey: "image") as! String
                self.imgViewMain.sd_setImage(with: URL.init(string: strUrl), placeholderImage: nil, options: .continueInBackground, completed: nil)
                
                self.lblName.text = self.dictSingleDirectory.value(forKey: "Name") as! String
                
                self.lblTag.text = self.dictSingleDirectory.value(forKey: "tag") as! String
                
                if self.dictSingleDirectory.value(forKey: "gallery") != nil{
                
                let arrImage = self.dictSingleDirectory.value(forKey: "gallery") as! NSArray
                
                for index in 0..<arrImage.count
                {
                    let dic = NSMutableDictionary()
                    dic.setValue("image", forKey: "type")
                    dic.setValue(arrImage.object(at: index), forKey: "image")
                    
                    self.arrImageAndVideo.add(dic)
                    
                    self.arrPhotos.add(MWPhoto.init(url: URL.init(string: arrImage.object(at: index) as! String)))

                }
                    

                }
                
                if self.dictSingleDirectory.value(forKey: "video") != nil{
                    
                    let strVideo = self.dictSingleDirectory.value(forKey: "video") as! String
                    
                    let dic = NSMutableDictionary()
                    dic.setValue("video", forKey: "type")
                    dic.setValue(strVideo, forKey: "image")
                    self.arrImageAndVideo.add(dic)
                }
                
                self.collectionView.reloadData()
                
                self.txtDescription.text = self.dictSingleDirectory.value(forKey: "description") as! String
                
            }
            
            
        }else{
            
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.arrImageAndVideo.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        let view = cell.contentView.viewWithTag(1000) as! UIView
        view.layer.borderWidth = 1.5
        view.layer.borderColor = UIColor.init(red: 224/255, green: 94/255, blue: 89/255, alpha: 1).cgColor
        
        let imgView = cell.contentView.viewWithTag(1001) as! UIImageView
        
        let dic = self.arrImageAndVideo.object(at: indexPath.item) as! NSDictionary
        
        if dic.value(forKey: "type") as! String == "video"{
            
        }
        else{
            let strImage = dic.value(forKey: "image") as! String
            
            imgView.sd_setImage(with: URL.init(string: strImage), placeholderImage: nil, options: .continueInBackground)

        }
        
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let dic = self.arrImageAndVideo.object(at: indexPath.item) as! NSDictionary
        
        if dic.value(forKey: "type") as! String == "video"{
            
            let strVideo = dic.value(forKey: "image")
            
            let videoURL = URL(string: strVideo as! String)
            let player = AVPlayer(url: videoURL!)
            let playerViewController = AVPlayerViewController()
            playerViewController.player = player
            self.present(playerViewController, animated: true) {
                playerViewController.player!.play()
            }
        }
        else{
            
            let controller = MWPhotoBrowser.init(photos: self.arrPhotos as! [Any])
            controller?.displayActionButton = false
            self.navigationController?.pushViewController(controller!, animated: true)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        
        let size = CGSize.init(width: 67, height: 67)
        
        return size
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {

        return UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        
        switch result {
            
        case .sent:
            break
            
        case .cancelled:
            
            controller.dismiss(animated: true, completion: nil)
            break
            
        default:
            
            break
        }

    }
    
    @objc func tapOnCall(gesture:UITapGestureRecognizer){
        
        let mobileNumber = "tel://\(self.dictSingleDirectory.value(forKey: "phone") as! String)"
        
        if let url = URL(string: mobileNumber),UIApplication.shared.canOpenURL(url){
            
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }

    }
    
    @objc func tapOnMail(gesture:UITapGestureRecognizer){
        
        if MFMailComposeViewController.canSendMail(){
            
            if MFMailComposeViewController.canSendMail(){
                
                let mailId = self.dictSingleDirectory.value(forKey: "email") as! String
                
                let controller = MFMailComposeViewController()
                controller.mailComposeDelegate = self
                controller.setSubject("Message")
                controller.setMessageBody("", isHTML: true)
                controller.setToRecipients([mailId])
                
                self.present(controller, animated: true, completion: nil)
                
            }
        }

    }
    
    @objc func tapOnWhatsapp(gesture:UITapGestureRecognizer){
        
     //   let strUrl = self.dictSingleDirectory.value(forKey: "WhatsApp") as! String
        
        let strNumber = self.dictSingleDirectory.value(forKey: "WhatsApp") as! String
        
        var strUrl = "https://api.whatsapp.com/send?phone=\(strNumber)&text=from 4breeders app"
        
        strUrl = strUrl.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        UIApplication.shared.open(URL.init(string: strUrl)!, options: [:], completionHandler: nil)
    }

}
