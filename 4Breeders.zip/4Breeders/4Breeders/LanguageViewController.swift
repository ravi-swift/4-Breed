//
//  ViewController.swift
//  4Breeders
//
//  Created by Rp on 26/04/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class LanguageViewController: UIViewController, UIGestureRecognizerDelegate,selectCountry {
    
    @IBOutlet weak var viewCountrySelect: UIView!
    @IBOutlet var lblCountry : UILabel!
    
    @IBOutlet weak var imgViewUsa: UIImageView!
    @IBOutlet weak var imgViewRussia: UIImageView!
    @IBOutlet weak var imgViewKuwait: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.navigationController?.navigationBar.isHidden = true
        
        viewCountrySelect.layer.borderWidth = 2
        viewCountrySelect.layer.borderColor = UIColor.white.cgColor
        
        let tapGestureUSA = UITapGestureRecognizer.init(target: self, action: #selector(clickOnUSAFlag))
        tapGestureUSA.delegate = self
        imgViewUsa.isUserInteractionEnabled = true
        imgViewUsa.addGestureRecognizer(tapGestureUSA)
        
        let tapGestureRussia = UITapGestureRecognizer.init(target: self, action: #selector(clickOnRussiaFlag))
        tapGestureRussia.delegate = self
        imgViewRussia.isUserInteractionEnabled = true
        imgViewRussia.addGestureRecognizer(tapGestureRussia)
        
        let tapGestureKuwait = UITapGestureRecognizer.init(target: self, action: #selector(clickOnKuwaitFlag))
        tapGestureKuwait.delegate = self
        imgViewKuwait.isUserInteractionEnabled = true
        imgViewKuwait.addGestureRecognizer(tapGestureKuwait)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.navigationBar.isHidden = true
    }
    
    @objc func clickOnUSAFlag(){
        
        imgViewUsa.layer.borderWidth = 2
        imgViewUsa.layer.cornerRadius = imgViewUsa.frame.size.height/2
        imgViewUsa.layer.masksToBounds = true
        imgViewRussia.layer.borderWidth = 0
        imgViewKuwait.layer.borderWidth = 0
        appDelegate.strLanguage = "en"
        
        UserDefaults.standard.set(appDelegate.strLanguage, forKey: "lang")
        UserDefaults.standard.synchronize()

    }
    
    @objc func clickOnRussiaFlag(){
        
        imgViewRussia.layer.borderWidth = 2
        imgViewRussia.layer.cornerRadius = imgViewRussia.frame.size.height/2
        imgViewRussia.layer.masksToBounds = true
        imgViewKuwait.layer.borderWidth = 0
        imgViewUsa.layer.borderWidth = 0
        appDelegate.strLanguage = "ru"
        
        UserDefaults.standard.set(appDelegate.strLanguage, forKey: "lang")
        UserDefaults.standard.synchronize()

    }
    
    @objc func clickOnKuwaitFlag(){
        
        imgViewKuwait.layer.borderWidth = 2
        imgViewKuwait.layer.cornerRadius = imgViewKuwait.frame.size.height/2
        imgViewKuwait.layer.masksToBounds = true
        imgViewRussia.layer.borderWidth = 0
        imgViewUsa.layer.borderWidth = 0
        appDelegate.strLanguage = "ar"
        
        UserDefaults.standard.set(appDelegate.strLanguage, forKey: "lang")
        UserDefaults.standard.synchronize()

    }
    
    @IBAction func clickOnLanguage(sender:UIButton)
    {
        
        let countryVC = self.storyboard?.instantiateViewController(withIdentifier: "CountrySelectViewController") as! CountrySelectViewController
        
        countryVC.delegate = self
        
        self.navigationController?.pushViewController(countryVC, animated: true)
        
        
    }
    
    func didFinishWithSuccessSelectCountry(dic: NSDictionary) {
        
     //   self.lblCountry.text = dic.value(forKey: "name") as? String
        
        appDelegate.strCountry = dic.value(forKey: "name") as! String
        self.lblCountry.text = appDelegate.strCountry
        
        UserDefaults.standard.set(appDelegate.strCountry, forKey: "name")
        UserDefaults.standard.synchronize()
        
        appDelegate.strCountryCode = dic.value(forKey: "abbr") as! String
      
        UserDefaults.standard.set(appDelegate.strCountryCode, forKey: "abbr")
        UserDefaults.standard.synchronize()
        
        appDelegate.setupTabbarcontroller()
    }
    
    
    
}

