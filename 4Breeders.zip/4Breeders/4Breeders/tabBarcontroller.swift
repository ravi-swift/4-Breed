//
//  TabVC.swift
//  Q8Star
//
//  Created by Ankit Gabani on 05/06/19.
//  Copyright © 2019 Ankit Gabani. All rights reserved.
//

import UIKit

class tabBarcontroller: UITabBarController, UITabBarControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupInitilView()
        
        // Do any additional setup after loading the view.
    }
    
    private func setupInitilView() {
        delegate = self
        
        UITabBar.appearance().barTintColor = UIColor(red: 15/255, green: 9/255, blue: 79/255, alpha: 1)
        
        let tabBarItemApperance = UITabBarItem.appearance()
        tabBarItemApperance.setTitleTextAttributes([NSAttributedString.Key.foregroundColor:UIColor(red: 164/255, green: 156/255, blue: 190/255, alpha: 1)], for: UIControl.State.normal)
        tabBarItemApperance.setTitleTextAttributes([NSAttributedString.Key.foregroundColor:UIColor.white], for: UIControl.State.selected)
        
    }

    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        let tabBarItemApperance = UITabBarItem.appearance()
        tabBarItemApperance.setTitleTextAttributes([NSAttributedString.Key.foregroundColor:UIColor(red: 164/255, green: 156/255, blue: 190/255, alpha: 1)], for: UIControl.State.normal)
        tabBarItemApperance.setTitleTextAttributes([NSAttributedString.Key.foregroundColor:UIColor.white], for: UIControl.State.selected)
    }

    
}
