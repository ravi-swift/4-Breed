//
//  AppDelegate.swift
//  4Breeders
//
//  Created by Rp on 26/04/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import FirebaseMessaging
import Firebase
import FirebaseInstanceID
import UserNotifications


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UITabBarControllerDelegate, responseDelegate,UNUserNotificationCenterDelegate,MessagingDelegate {

    var window: UIWindow?

    var strLanguage : String = "en"
    
    var strCountryCode : String = ""
    var strDeviceToken : String = ""
    
    var strCountry : String = ""

    var mobileId : String = ""
    
    var dictStaticWord = NSDictionary()
    var adsView = UIView()

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        print(dictStaticWord)
        
        self.getAllStaticWord()
        
        IQKeyboardManager.shared.enable = true
        
        mobileId = ((UIDevice.current.identifierForVendor?.uuidString)!)
        
        print(mobileId)
        
        if UserDefaults.standard.object(forKey: "name") != nil
        {
            self.strCountry = UserDefaults.standard.object(forKey: "name") as! String
        }else{
            self.strCountry = "Kuwait"
        }
        
        if UserDefaults.standard.object(forKey: "abbr") != nil
        {
            self.strCountryCode = UserDefaults.standard.object(forKey: "abbr") as! String
        }else{
            self.strCountryCode = "+965"
        }
        
        if UserDefaults.standard.bool(forKey: "isAlreadyOpen") == false{
            
            UserDefaults.standard.set(true, forKey: "isAlreadyOpen")
            UserDefaults.standard.synchronize()
        }
        else{
            self.setupTabbarcontroller()
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(languageChangedDone), name: NSNotification.Name(rawValue: "languageChanged"), object: nil)
        
        FirebaseApp.configure()
        
        if #available(iOS 10.0, *) {
            
            let center = UNUserNotificationCenter.current()
            center.delegate  = self
            center.requestAuthorization(options:[.badge, .alert, .sound]) { (granted, error) in
                if (granted)
                {
                    DispatchQueue.main.async {
                        application.registerForRemoteNotifications()
                    }
                    
                }
            }
        }
        else{
            
            let settings = UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil)
            UIApplication.shared.registerUserNotificationSettings(settings)
            application.registerForRemoteNotifications()
            
        }
        
        self.ConnectToFCM()
        
        
        return true
    }
    
    func ConnectToFCM() {
        
        
        Messaging.messaging().shouldEstablishDirectChannel = true
        Messaging.messaging().delegate = self
        InstanceID.instanceID().instanceID { (result, error) in
            if let error = error {
                print("Error fetching remote instange ID: \(error)")
            } else if let result = result {
                print("Remote instance ID token: \(result.token)")
                self.strDeviceToken = result.token
                self.setPush()
            }
        }
        
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        
        completionHandler(.newData)
    }
    
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String) {
        
        print("Firebase registration token: \(fcmToken)")
        
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        completionHandler()
        
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        completionHandler(.alert)
    }
    
    func messaging(_ messaging: Messaging, didReceive remoteMessage: MessagingRemoteMessage) {
        
        print("%@", remoteMessage.appData)
        
    }
    
    func setPush()
    {
        
        let strURL = NSString.init(format:"fcm_id=%@",self.strDeviceToken)
        
        let url = URL.init(string: "http://4breeders.com/Api/Fcm")
        
        let request = NSMutableURLRequest(url: url!)
        request.httpMethod = "POST"
        request.httpBody = strURL.data(using: String.Encoding.utf8.rawValue)
        
        let dataTask = URLSession.shared.dataTask(with: request as URLRequest) {data,response,error in
            
            
            if (error != nil) {
                print(error!)
            } else {
                
                let responseString = String(data: data!, encoding: .utf8)
                print("responseString = \(String(describing: responseString))")
                
                DispatchQueue.main.async {
                    
                    do{
                        
                        let json = try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves) as! NSDictionary
                        
                    }
                    catch{
                        
                    }
                    
                }
            }
            
        }
        dataTask.resume()
    }
    
    
    @objc func languageChangedDone(){

        self.getAllStaticWord()
    }

    
    func getAllStaticWord(){
        
        if UserDefaults.standard.value(forKey: "lang") != nil{
            
            self.strLanguage = UserDefaults.standard.value(forKey: "lang") as! String
        }
        
        let strParam = "lang=\(self.strLanguage)"
        
        let strUrl = "http://sachinsam.com/4breeders/Api/Options"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getAllStaticWord", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        print(Response)
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                let arrStaticWord = Response.value(forKey: "data") as! NSArray
                
                self.dictStaticWord = arrStaticWord.object(at: 0) as! NSDictionary
                
                print(self.dictStaticWord)
                
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadCategory"), object: nil, userInfo: nil)
            }
            
            
        }else{
            
        }

    }
    
    func setupTabbarcontroller()
    {
        if UserDefaults.standard.object(forKey: "lang") != nil{
            self.strLanguage = UserDefaults.standard.object(forKey: "lang") as! String
        }
        
        self.getAllStaticWord()

        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        
        let tabBarcontroller = storyBoard.instantiateViewController(withIdentifier: "tabBarcontroller") as! UITabBarController
        
        adsView.frame = CGRect.init(x: (UIScreen.main.bounds.size.width)/5 * 4, y: 0, width: (UIScreen.main.bounds.size.width)/5, height: tabBarcontroller.tabBar.frame.size.height)
        adsView.backgroundColor = UIColor.init(red: 238/255, green: 171/255, blue: 167/255, alpha: 1)
        tabBarcontroller.tabBar.addSubview(adsView)
        
        tabBarcontroller.delegate = self
        
        for navigation in tabBarcontroller.viewControllers!
        {
            let nav = navigation as! UINavigationController
            nav.navigationBar.barTintColor = UIColor.init(red: 239/255, green: 101/255, blue: 90/255, alpha: 1)
            nav.navigationBar.isHidden = false
            nav.navigationBar.tintColor = UIColor.white
            
            nav.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor:UIColor.white]
            
            let controller = nav.viewControllers[0]
            
            var strImg : String = ""
            
            var strTitle : String = ""
            
            if controller.isKind(of: HomeViewController.self)
            {
                strImg = "Home_Icon"
                
                if strLanguage == "en"
                {
                    strTitle = "Home"
                    
                }else if strLanguage == "ar"
                {
                    strTitle = "الرئيسية"
                    
                }else{
                    
                    strTitle = "Главная"
                }
                
            }
            else if controller.isKind(of: AllBidsTblViewController.self)
            {
                strImg = "bid_icon"
                
                if strLanguage == "en"
                {
                    strTitle = "Auctions"
                    
                }else if strLanguage == "ar"
                {
                    strTitle = "المزاد"
                    
                }else{
                    
                    strTitle = "Торг"
                }
            }
            else if controller.isKind(of: AdsViewController.self){
                
                strImg = "add_bid_icon"
                
                if strLanguage == "en"
                {
                    strTitle = "Add Ads"
                    
                }else if strLanguage == "ar"
                {
                    strTitle = "اضف اعلانك"
                    
                }else{
                    
                    strTitle = "Публиковать"
                }
            }
            else if controller.isKind(of: DirectoryViewController.self){
                
                strImg = "worldwide"
                
                if strLanguage == "en"
                {
                    strTitle = "Breeders"
                    
                }else if strLanguage == "ar"{
                    
                    strTitle = "المربين"
                    
                }else{
                    
                    strTitle = "заводчики"
                }
            }
            else {
                strImg = "More_icon"
                
                if strLanguage == "en"
                {
                    strTitle = "More"
                    
                }else if strLanguage == "ar"
                {
                    strTitle = "المزيد"
                    
                }else{
                    
                    strTitle = "Больше"
                }
            }
            
            var image = UIImage.init(named: strImg)
            image = image?.withRenderingMode(.alwaysTemplate)
            
            navigation.tabBarItem.image = image
            
            navigation.tabBarItem.title = strTitle
            
           // navigation.tabBarItem.imageInsets = UIEdgeInsets.init(top: 6, left: 0, bottom: -6, right: 0)
        }
        
        tabBarcontroller.selectedIndex = 4
       // tabBarcontroller.tabBar.unselectedItemTintColor = UIColor.init(red: 196.0/255.0, green: 196.0/255.0, blue: 196.0/255.0, alpha: 1.0)
   //     tabBarcontroller.tabBar.unselectedItemTintColor = UIColor.init(red: 243/255, green: 152/255, blue: 143/255, alpha: 1)
        tabBarcontroller.tabBar.unselectedItemTintColor = UIColor.white
        tabBarcontroller.tabBar.tintColor = UIColor.black
   //     tabBarcontroller.tabBar.barTintColor = UIColor.white
        tabBarcontroller.tabBar.barTintColor = UIColor.init(red: 236.0/255.0, green: 103.0/255.0, blue: 90.0/255.0, alpha: 1.0)
        
        
        
        self.window?.rootViewController = tabBarcontroller
        self.window?.makeKeyAndVisible()
    }

    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        
        let index = (tabBarController.viewControllers as! NSArray).index(of: viewController)
        
        adsView.frame = CGRect.init(x: ((UIScreen.main.bounds.size.width)/5) * (CGFloat)(index), y: 0, width: (UIScreen.main.bounds.size.width)/5, height: tabBarController.tabBar.frame.size.height)
        adsView.backgroundColor = UIColor.init(red: 238/255, green: 171/255, blue: 167/255, alpha: 1)
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        
        self.ConnectToFCM()

    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

