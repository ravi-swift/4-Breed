//
//  ContactUsViewController.swift
//  4Breeders
//
//  Created by Rp on 30/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class ContactUsViewController: UIViewController,responseDelegate {

    @IBOutlet weak var txvDescription: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.getContactUs()
    }
    
    func getContactUs(){
        
        let strParam = "lang=\(appDelegate.strLanguage)"
        
        let strUrl = "http://4breeders.com/Api/Contact/contactdetails"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getAboutData", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
        
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                let arrContactUS = Response.value(forKey: "data") as! NSArray
                
                let dictContactUs = arrContactUS.object(at: 0) as! NSDictionary
                
                self.txvDescription.attributedText = (dictContactUs.value(forKey: "description") as! String).html2AttributedString
                
                self.txvDescription.textAlignment = .right
            }
            
            
        }else{
            
        }
    }

}
