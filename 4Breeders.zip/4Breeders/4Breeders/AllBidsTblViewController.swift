//
//  AllBidsTblViewController.swift
//  4Breeders
//
//  Created by Rp on 22/05/19.
//  Copyright © 2019 Dharmesh Sonani. All rights reserved.
//

import UIKit

class AllBidsTblViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,responseDelegate,UIGestureRecognizerDelegate {
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var imgViewHeader: UIImageView!
    
    var arrAllBids = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.getAllBids()
        
        let strUrlImg = "http://4breeders.com/banner2.png"
        
        imgViewHeader.sd_setImage(with: URL.init(string: strUrlImg), placeholderImage: nil, options: .continueInBackground)
        
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(tapOnImgHeader(gesture:)))
        tapGesture.delegate = self
        imgViewHeader.isUserInteractionEnabled = true
        imgViewHeader.addGestureRecognizer(tapGesture)
        
        NotificationCenter.default.addObserver(self, selector: #selector(languageChangedDone), name: NSNotification.Name(rawValue: "languageChanged"), object: nil)
    }
    
    @objc func languageChangedDone(){

        self.getAllBids()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationItem.title = "4BREEDERS"
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 20)]
        
        if UIScreen.main.bounds.size.height > 667
        {
            let imgView = UIImageView()
            imgView.frame = CGRect.init(x: 0, y: -20, width: UIScreen.main.bounds.size.width, height: 64)
            imgView.image = UIImage.init(named: "header-bg-w-background")
            
            self.navigationController?.navigationBar.insertSubview(imgView, at: 1)
        }
        else{
            self.navigationController?.navigationBar.setBackgroundImage(UIImage.init(named: "header-bg-w-background"), for: .default)
            
        }
        
        if appDelegate.strLanguage == "en"{
            
            var img = UIImage.init(named: "usa_flag")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else if appDelegate.strLanguage == "ru"{
            
            var img = UIImage.init(named: "russia_flagSmall")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
            
        }else{
            
            var img = UIImage.init(named: "kuwait_flagSmall")
            img = img?.withRenderingMode(.alwaysOriginal)
            
            let leftBarBtn = UIBarButtonItem.init(image: img, style: .plain, target: self, action: #selector(clickOnLeftBarBtn(btn:)))
            leftBarBtn.imageInsets = UIEdgeInsets(top: 0.0, left: -5, bottom: 0, right: 0);
            
            self.navigationItem.leftBarButtonItem = leftBarBtn
        }
        
        let rightBarBtn = UIBarButtonItem.init(image: UIImage.init(named: "search_icon"), style: .plain, target: self, action: #selector(clickOnRightBarBtn(btn:)))
        self.navigationItem.rightBarButtonItem = rightBarBtn
        
        self.navigationController?.navigationBar.isTranslucent = false
        
    }
    
    func getAllBids(){
        
        let strParam = "lang=\(appDelegate.strLanguage)"
        
        let strUrl = "http://4breeders.com/Api/Bid/getbid"
        
        WebParserWS.fetchDataWithURL(url: strUrl as NSString, type: .TYPE_POST, ServiceName: "getAllBids", bodyObject: strParam as AnyObject, delegate: self, isShowProgress: true)
    }
    
    func didFinishWithSuccess(ServiceName: String, Response: AnyObject) {
        
        let result = "\(Response.value(forKey: "status") as! Int)"
        
        if result == "1"{
            
            DispatchQueue.main.async {
                
                self.arrAllBids = Response.value(forKey: "data") as! NSArray
                print(self.arrAllBids)
                self.tblView.reloadData()
            }
            
            
        }else{
            
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrAllBids.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let imgView = cell.contentView.viewWithTag(1001) as! UIImageView
        let lblRemainigTimeStatic = cell.contentView.viewWithTag(1002) as! UILabel
        
        if appDelegate.dictStaticWord.count > 0{
            
            lblRemainigTimeStatic.text = appDelegate.dictStaticWord.value(forKey: "Remaining Time") as? String
        }
        
        let lblTime = cell.contentView.viewWithTag(1003) as! UILabel
        let lblTitle = cell.contentView.viewWithTag(1004) as! UILabel
        let lblBidType = cell.contentView.viewWithTag(1005) as! UILabel
        
        let dictAllBids = self.arrAllBids.object(at: indexPath.row) as! NSDictionary
        
        let strUrlImg = dictAllBids.value(forKey: "image") as! String
        
        imgView.sd_setImage(with: URL.init(string: strUrlImg), placeholderImage: nil, options: .continueInBackground, completed: nil)
        
        lblTitle.text = dictAllBids.value(forKey: "bid_name") as? String
        
      //  lblTime.text = dictAllBids.value(forKey: "Close_Timer") as? String
        
        lblBidType.text = dictAllBids.value(forKey: "bid_type") as? String
        
        Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(remainingTime), userInfo: indexPath, repeats: true)
        
        return cell
    }
    
    @objc func remainingTime(timer:Timer){
        
        let userInfo = timer.userInfo as! IndexPath
        
        let cell = tblView.cellForRow(at: userInfo)
        if cell != nil{
            let lblTime = cell!.contentView.viewWithTag(1003) as! UILabel
            let dictAllBids = self.arrAllBids.object(at: userInfo.row) as! NSDictionary
            
            let strDate = "\(dictAllBids.value(forKey: "Day") as! String) \(dictAllBids.value(forKey: "Start_Time") as! String):00"
            
            let currentDate = Date()
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy hh:mm:ss"
            let today = dateFormatter.string(from: currentDate)
            let todayDate = dateFormatter.date(from: today)
            
            let futureDate = dateFormatter.date(from: strDate)
            if futureDate != nil{
                let difference = Calendar.current.dateComponents([.hour, .minute, .second], from: todayDate!, to: futureDate!)
                let formattedString = String(format: "%02ld:%02ld:%02ld", difference.hour!, difference.minute!,difference.second!)
                
                if difference.hour! > 0 && difference.minute! > 0{
                    
                    lblTime.text = formattedString
                }
                else{
                    
                    lblTime.text = "00:00:00"
                }
                
         //       lblTime.text = formattedString
            }
//            else{
//                lblTime.text = ""
//            }
            
            
        }
        
      
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let bidDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "BidViewController") as! BidViewController
        
        bidDetailVC.dictAllBidDetails = self.arrAllBids.object(at: indexPath.row) as! NSDictionary
        
        self.navigationController?.pushViewController(bidDetailVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 260
    }
    
//    @objc func setReamainingTime()
//    {
//        let dictAllBids = self.arrAllBids.object(at: indexPath.row) as! NSDictionary
//
//        let strDate = "\(dictAllBids.value(forKey: "Date") as! String) \(dictAllBids.value(forKey: "Start_Time") as! String):00"
//
//        let currentDate = Date()
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "dd-MM-yyyy hh:mm:ss"
//        let today = dateFormatter.string(from: currentDate)
//        let todayDate = dateFormatter.date(from: today)
//
//        let futureDate = dateFormatter.date(from: strDate)
//
//        let difference = Calendar.current.dateComponents([.hour, .minute, .second], from: todayDate!, to: futureDate!)
//        let formattedString = String(format: "%02ld:%02ld:%02ld", difference.hour!, difference.minute!,difference.second!)
//        print(formattedString)
//
//        lblTime.text = formattedString
//    }
    
    @objc func clickOnLeftBarBtn(btn:UIButton){
        
        let settingVC = self.storyboard?.instantiateViewController(withIdentifier: "SeetingViewController") as! SeetingViewController
        
        self.navigationController?.pushViewController(settingVC, animated: true)
    }
    
    @objc func clickOnRightBarBtn(btn:UIButton){
        
        let searchVC = self.storyboard?.instantiateViewController(withIdentifier: "SearchBarViewController") as! SearchBarViewController
        
        self.navigationController?.pushViewController(searchVC, animated: true)
    }

    @objc func tapOnImgHeader(gesture:UITapGestureRecognizer){
        
        let strUrl = "http://4breeders.com/banner2.php"
        
        UIApplication.shared.open(URL.init(string: strUrl)!, options: [:], completionHandler: nil)
    }
    
}
